<?php 
$selfintro_data = '';
if (function_exists( 'fw_get_db_settings_option' )):	
	$selfintro_data = fw_get_db_settings_option();  
endif;
$heading = '';
if(!empty($selfintro_data['shop_heading'])):
    $heading = $selfintro_data['shop_heading'];
endif;
$sub_heading = '';
if(!empty($selfintro_data['shop_sub_heading'])):
    $sub_heading = $selfintro_data['shop_sub_heading'];
endif;
$producted_show = '';
if(!empty($selfintro_data['shop_product_show'])):
   $producted_show = $selfintro_data['shop_product_show'];
   else:
   $producted_show = 6;
endif;
$product_load = '';
if(!empty($selfintro_data['shop_product_load'])):
    $product_load = $selfintro_data['shop_product_load'];
endif;  
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif; 
?>  
<!--<div class="row">-->
<div class="self_woocommerce_wrapper prt_toppadder80">
 <div class="container">
  <div class="row">
    <?php if(!empty($heading) || !empty($sub_heading)): ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="prt_heading_wrapper">
					<div class="prt_heading">
					    <?php if(!empty($heading)): ?>
						   <h1><?php printf($heading); ?></h1>
						<?php  
						endif;
						if(!empty($sub_heading)): 
						    if($typedsettings == 'on'): 
							    echo'<div class="typed_strings_product">
								  <p class="write_product" data-strings-product="'.esc_html($sub_heading).'">'.esc_html($sub_heading).'</p></div>';
						    else:  
						        echo '<p>'.esc_html($sub_heading).'</p>';
					        endif;
					    endif; 
						?>  
					</div>
				</div>
            </div> 
            <?php endif; ?>
			<div class="self_woocommerce_product">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="ajax_product_shortcode">
			<?php 
            $args = '';
	        $args = array(
                'post_type' =>'product',
                'posts_per_page' =>$producted_show,
                );
            $tr_query = new WP_Query($args); 
            if($tr_query->have_posts()) :
	        while($tr_query->have_posts()): $tr_query->the_post();
		     if(class_exists("Woocommerce")){
			   wc_get_template_part( 'content', 'product' );
			 }
	        endwhile;
            wp_reset_postdata();
	        endif;
           ?>
          </div>
	    </div> 
	   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center ajxload">
			<button class="prt_btn product_load">
			<?php esc_html_e('load more','selfintro'); ?></button>
			<div class="prt_loader"><div class="loader"></div></div>
			<input type="hidden" value="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"  id="ajaxurl">
			<input type="hidden" class="ajx_auto_incriment"  value="1" />
			<input type="hidden" class="ajx_prot_number"  value="<?php echo esc_attr($producted_show); ?>" />
			<input type="hidden" class="ajx_prot_showmore"  value="<?php echo esc_attr($product_load); ?>" />
		</div> 
	 </div> 
    </div>
  </div>
  <?php selfintro_footer_copyright(); ?>
<!--</div>-->  