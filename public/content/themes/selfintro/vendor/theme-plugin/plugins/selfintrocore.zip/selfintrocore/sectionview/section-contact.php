<?php 
if(function_exists( 'fw_get_db_settings_option' )):	
	$selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?> 
<div class="prt_contact_wrapper prt_toppadder115">
		<div class="prt_close_wrapper">
		   <i class="fa fa-chevron-left prt_close"></i>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="prt_heading_wrapper">
					    <?php
					    $contact_us_heading = '';
                        if(!empty($selfintro_data['contact_us_heading'])):
                           $contact_us_heading = $selfintro_data['contact_us_heading'];
                        endif;
                        $contact_us_sub_heading = '';
                        if(!empty($selfintro_data['contact_us_sub_heading'])):
                            $contact_us_sub_heading = $selfintro_data['contact_us_sub_heading'];
                        endif;
					    if(!empty($contact_us_heading)):
						    echo '<div class="prt_heading">
							       <h1>'.esc_html($contact_us_heading).'</h1>';
								   if($typedsettings == 'on'): 
								    echo'<div class="typed_strings_contact">
									      <p class="write_contact" data-strings-contact="'.esc_html($contact_us_sub_heading).'">'.esc_html($contact_us_sub_heading).'</p>
								        </div>';
									else: 
										echo '<p>'.esc_html($contact_us_sub_heading).'</p>';
									endif;
							echo '</div>';
						endif;
						?>
					</div>
				</div> 
				<div class="prt_contact_box">
				    <?php 
				    $form_heading = '';
                    if(!empty($selfintro_data['form_heading'])):
                       $form_heading = $selfintro_data['form_heading'];
                    endif;
                    $form_shortcode = '';
                    if(!empty($selfintro_data['form_shortcode'])):
                       $form_shortcode = $selfintro_data['form_shortcode'];
                    endif;
                    $googlemap_ifram = '';
                    if(!empty($selfintro_data['googlemap_ifram'])):
                       $googlemap_ifram = $selfintro_data['googlemap_ifram'];
                    endif;
				    ?>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prt_contact_info">
						    <?php if(!empty($form_heading)): ?>
							   <h1><?php echo esc_html($form_heading); ?></h1>
							<?php endif; ?>
							<div class="prt_contact_form">
								<div class="row">
								<?php echo do_shortcode($form_shortcode); ?>
								</div>
							</div>
						</div>
					</div> 
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prt_contact_map">
						   <?php
						    if(!empty($googlemap_ifram)): 
						        print($googlemap_ifram);
						    else:
							$map_address = '';
							if(!empty($selfintro_data['map_address'])):
								$map_address = $selfintro_data['map_address'];
							endif;
							$longitude = -73.945;
							if(!empty($selfintro_data['longitude'])):
								$longitude = $selfintro_data['longitude'];
							endif;
							$latitude =40.674;
							if(!empty($selfintro_data['latitude'])):
								$latitude = $selfintro_data['latitude'];
							endif;
							$map_zoom = 12;
							if(!empty($selfintro_data['map_zoom'])):
								$latitude = $selfintro_data['map_zoom'];
							endif;
							$geometry = '';
							if(!empty($selfintro_data['geometry'])):
								$geometry = $selfintro_data['geometry'];
							else:
								$geometry = '#242f3e';
							endif;
							$labelstextfill = '';
							if(!empty($selfintro_data['labelstextfill'])):
								$labelstextfill = $selfintro_data['labelstextfill'];
							else:
								$labelstextfill = '#746855';
							endif;
							$labelstextstroke = '';
							if(!empty($selfintro_data['labelstextstroke'])):
								$labelstextstroke = $selfintro_data['labelstextstroke'];
							else:
								$labelstextstroke = '#242f3e';
							endif;
							$locality_text_fill_color = '';
							if(!empty($selfintro_data['locality_text_fill_color'])):
								$locality_text_fill_color = $selfintro_data['locality_text_fill_color'];
							else:
								$locality_text_fill_color = '#d59563';
							endif;
							$poi_text_fill_color = '';
							if(!empty($selfintro_data['poi_text_fill_color'])):
								$poi_text_fill_color = $selfintro_data['poi_text_fill_color'];
							else:
								$poi_text_fill_color = '#d59563';
							endif;
							$poi_park_geometry_color = '';
							if(!empty($selfintro_data['poi_park_geometry_color'])):
								$poi_park_geometry_color = $selfintro_data['poi_park_geometry_color'];
							else:
								$poi_park_geometry_color = '#263c3f';
							endif;
							$poipark_text_fill_color = '';
							if(!empty($selfintro_data['poipark_text_fill_color'])):
								$poipark_text_fill_color = $selfintro_data['poipark_text_fill_color'];
							else:
								$poipark_text_fill_color = '#6b9a76';
							endif;
							$road_geometry_color = '';
							if(!empty($selfintro_data['road_geometry_color'])):
								$road_geometry_color = $selfintro_data['road_geometry_color'];
							else:
								$road_geometry_color = '#38414e';
							endif;
							$road_geometry_stroke_color = '';
							if(!empty($selfintro_data['road_geometry_stroke_color'])):
								$road_geometry_stroke_color = $selfintro_data['road_geometry_stroke_color'];
							else:
								$road_geometry_stroke_color = '#212a37';
							endif;
							$road_text_fill_color = '';
							if(!empty($selfintro_data['road_text_fill_color'])):
								$road_text_fill_color = $selfintro_data['road_text_fill_color'];
							else:
								$road_text_fill_color = '#9ca5b3';
							endif;
							$road_highway_geometry_color = '';
							if(!empty($selfintro_data['road_highway_geometry_color'])):
								$road_highway_geometry_color = $selfintro_data['road_highway_geometry_color'];
							else:
								$road_highway_geometry_color = '#746855';
							endif;
							$roadhighway_geometry_stroke_color = '';
							if(!empty($selfintro_data['roadhighway_geometry_stroke_color'])):
								$roadhighway_geometry_stroke_color = $selfintro_data['roadhighway_geometry_stroke_color'];
							else:
								$roadhighway_geometry_stroke_color = '#1f2835';
							endif;
							$roadhighway_text_fill_color = '';
							if(!empty($selfintro_data['roadhighway_text_fill_color'])):
								$roadhighway_text_fill_color = $selfintro_data['roadhighway_text_fill_color'];
							else:
								$roadhighway_text_fill_color = '#f3d19c';
							endif;
							$transit_geometry_color = '';
							if(!empty($selfintro_data['transit_geometry_color'])):
								$transit_geometry_color = $selfintro_data['transit_geometry_color'];
							else:
								$transit_geometry_color = '#2f3948';
							endif;
							$transitstation_text_fill_color = '';
							if(!empty($selfintro_data['transitstation_text_fill_color'])):
								$transitstation_text_fill_color = $selfintro_data['transitstation_text_fill_color'];
							else:
								$transitstation_text_fill_color = '#d59563';
							endif;
							$water_geometry = '';
							if(!empty($selfintro_data['water_geometry'])):
								$water_geometry = $selfintro_data['water_geometry'];
							else:
								$water_geometry = '#17263c';		
							endif;
							$water_text_fill_color = '';
							if(!empty($selfintro_data['water_text_fill_color'])):
								$water_text_fill_color = $selfintro_data['water_text_fill_color'];
							else:
								$water_text_fill_color = '#515c6d';	
							endif;
							$water_text_stroke_color = '';
							if(!empty($selfintro_data['water_text_stroke_color'])):
							$water_text_stroke_color = $selfintro_data['water_text_stroke_color'];
							else:
								$water_text_stroke_color= '#17263c';
							endif;
							?>  
						<div class="sl_color_map">
                         <div id="map"></div> 
                       </div>
                    <script>
                   // Styles a map in night mode.
                  var map = new google.maps.Map(document.getElementById('map'), {
                  center: {lat: <?php echo esc_js($latitude); ?>, lng: <?php echo esc_js($longitude); ?>},
                 zoom: <?php echo esc_js($map_zoom); ?>,
              styles: [
					            {elementType: 'geometry', stylers: [{color: '<?php echo esc_js($geometry);?>'}]},
					            {elementType: 'labels.text.stroke', stylers: [{color: '<?php echo esc_js($labelstextstroke);?>'}]},
					            {elementType: 'labels.text.fill', stylers: [{color: '<?php echo esc_js($labelstextfill);?>'}]},
					            {
					              featureType: 'administrative.locality',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '<?php echo esc_js($locality_text_fill_color);?>'}]
					            },
					            {
					              featureType: 'poi',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '<?php echo esc_js($poi_text_fill_color);?>'}]
					            },
					            {
					              featureType: 'poi.park',
					              elementType: 'geometry',
					              stylers: [{color: '<?php echo esc_js($poi_park_geometry_color);?>'}]
					            },
					            {
					              featureType: 'poi.park',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '<?php echo esc_js($poipark_text_fill_color);?>'}]
					            },
					            {
					              featureType: 'road',
					              elementType: 'geometry',
					              stylers: [{color: '<?php echo esc_js($road_geometry_color);?>'}]
					            },
					            {
					              featureType: 'road',
					              elementType: 'geometry.stroke',
					              stylers: [{color: '<?php echo esc_js($road_geometry_stroke_color);?>'}]
					            },
					            {
					              featureType: 'road',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '<?php echo esc_js($road_text_fill_color);?>'}]
					            },
					            {
					              featureType: 'road.highway',
					              elementType: 'geometry',
					              stylers: [{color: '<?php echo esc_js($road_highway_geometry_color);?>'}]
					            },
					            {
					              featureType: 'road.highway',
					              elementType: 'geometry.stroke',
					              stylers: [{color: '<?php echo esc_js($roadhighway_geometry_stroke_color);?>'}]
					            },
					            {
					              featureType: 'road.highway',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '<?php echo esc_js($roadhighway_text_fill_color);?>'}]
					            },
					            {
					              featureType: 'transit',
					              elementType: 'geometry',
					              stylers: [{color: '<?php echo esc_js($transit_geometry_color);?>'}]
					            },
					            {
					              featureType: 'transit.station',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '<?php echo esc_js($transitstation_text_fill_color);?>'}]
					            },
					            {
					              featureType: 'water',
					              elementType: 'geometry',
					              stylers: [{color: '<?php echo esc_js($water_geometry);?>'}]
					            },
					            {
					              featureType: 'water',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '<?php echo esc_js($water_text_fill_color);?>'}]
					            },
					            {
					              featureType: 'water',
					              elementType: 'labels.text.stroke',
					              stylers: [{color: '<?php echo esc_js($water_text_stroke_color);?>'}]
					            }
					          ]
        });
        </script> 
		<?php endif; ?>
		  </div>
		</div>
		</div>
				<div class="prt_contact_details">
				    <?php 
				    $contactus_detail = '';
                    if(!empty($selfintro_data['contactus_detail'])):
                       $contactus_detail = $selfintro_data['contactus_detail'];
                    endif;
                    if(!empty($contactus_detail)):
				      foreach($contactus_detail as $addinfo):
				          $cs_bg_image = '';
				          if(!empty($addinfo['add_bg_image']['url'])):
				           $cs_bg_image = $addinfo['add_bg_image']['url'];
				          endif;
				          $bg_image_url = '';
                        if(!empty($cs_bg_image)):
                            $bg_image_url = 'background-image:url(' .$cs_bg_image. ');';
                        endif;
                        $title = '';
                        if(!empty($addinfo['title'])):
                           $title = $addinfo['title'];
                        endif;
                        $address_info = '';
                        if(!empty($addinfo['address_info'])):
                           $address_info = $addinfo['address_info'];
                        endif;
                        
                        if(!empty($address_info)):
                         ?>
				         <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
    						<div class="prt_contact_details_box details_box1" style=<?php printf($bg_image_url); ?>>
    						    <?php if(!empty($title)): ?>
    						       <h4><?php echo esc_html($title); ?></h4>
    							<?php
    							endif;
    							print($address_info); ?>
    						 </div>
					     </div>
					   <?php
					     endif;
					  endforeach;
					endif;
					?> 
				</div>
			</div>
		</div>
		<?php selfintro_footer_copyright(); ?>	
    </div> 