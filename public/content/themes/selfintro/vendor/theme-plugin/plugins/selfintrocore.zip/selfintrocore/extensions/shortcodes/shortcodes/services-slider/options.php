<?php if(!defined('FW')) {
	die( 'Forbidden' );
}
$options = array(
'services_heading'  => array( 
			'label' => esc_html__('Services Heading', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			), 	 
'services_sub_heading'  => array( 
			'label' => esc_html__('Services Sub Heading', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			),
'numberof_services'  => array( 
			'label' => esc_html__('Number Of Services', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			), 				
);			