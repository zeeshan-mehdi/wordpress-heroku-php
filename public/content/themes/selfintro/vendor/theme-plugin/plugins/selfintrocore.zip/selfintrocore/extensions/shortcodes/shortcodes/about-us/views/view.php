<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} 
$about_image = '';
    if(!empty($atts['about_image']['url'])):
        $about_image = $atts['about_image']['url'];
    endif;
    $heading = '';
    if(!empty($atts['heading'])):
        $heading = $atts['heading'];
    endif;
    $heading_sub = '';
    if(!empty($atts['heading_sub'])):
        $heading_sub = $atts['heading_sub'];
    endif;
    $descreption = '';
    if(!empty($atts['about_desc'])):
        $descreption = $atts['about_desc'];
    endif;
    $resume_download = '';
    if(!empty($atts['resume_download'])):
        $resume_download = $atts['resume_download'];
    endif;
    $hire_me = '';
    if(!empty($atts['hire_me'])):
        $hire_me = $atts['hire_me'];
    endif;
	if(function_exists( 'fw_get_db_settings_option' )):	
	$selfintro_data = fw_get_db_settings_option();  
    endif; 
	$typedsettings = '';
	if(!empty($selfintro_data['banner_switch_typed'])):
		$typedsettings =$selfintro_data['banner_switch_typed'];
	endif; 
?>
<div class="container">
	<div class="row">
	   <div class="prt_about_info prt_bottompadder80">
		   <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
			   <?php if(!empty($about_image)): ?>
				  <div class="prt_about_img">
					<img src="<?php echo esc_url($about_image); ?>" alt="<?php esc_html_e('About','selfintro'); ?>">
				   </div>
				 <?php endif; ?>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="prt_heading_wrapper_2">
					<div class="prt_heading prt_toppadder50">
						<h1><?php echo esc_html($heading); ?></h1>
						<?php 
						 if($typedsettings == 'on'): ?>
						    <div class="typed_strings_about">
						      <p class="write_about" data-strings-about="<?php echo esc_html($heading_sub); ?>"><?php echo esc_html($heading_sub); ?></p>
							</div> 
						<?php else: ?>  
						     <p><?php echo esc_html($heading_sub); ?></p>
						<?php endif; ?>
					</div>   
				</div> 
			<?php if(!empty($descreption)): ?>
			<div class="prt_about_details">
				<p><?php printf($descreption); ?></p>
			<?php 
			if(!empty($resume_download)): ?>
				<a href="<?php echo esc_url($resume_download); ?>" class="prt_btn">
			<?php esc_html_e('Download Resume','selfintro'); ?></a> 
			 <?php 
			endif;
			if(!empty($hire_me)):
				echo '<a href="'.esc_url($hire_me).'" class="prt_btn">'.esc_html__('Hire Me','selfintro').'</a>';
			endif;
			?>
			</div>
		     <?php endif; ?>
			</div>
		</div>
	</div>
 </div>