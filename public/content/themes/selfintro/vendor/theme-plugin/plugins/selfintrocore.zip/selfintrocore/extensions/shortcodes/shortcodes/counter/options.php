<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} 
$options = array(
     'award_bg_image'  => array( 
			  'label' => esc_html__('Award Background Image', 'selfintro'),
			  'desc' => esc_html__('Upload Award Background Image Here.', 'selfintro'),
			   'type' => 'upload', 
			 ), 
     'our_award' =>array( 
		      'type' => 'addable-popup',
		      'value' => array( 
			   array(
				    'our_award' => 'Our Award',
			        ),
	     	     ),
		      'label' => esc_html__('Add Award', 'selfintro'),
		      'template' => '{{- objectives_title }}',
		      'popup-title' => null,
		      'size' => 'small', 
		      'limit' => 0,  
	      	  'add-button-text' => esc_html__('Add', 'selfintro'), 
		      'sortable' => true,
	'popup-options' => array(
		 'award_title' => array(
		          'label' => esc_html__('Title', 'selfintro'),
		          'type' => 'text', 
	             ),
	     'award_number' => array(
		           'label' => esc_html__('Number', 'selfintro'),
		           'type' => 'text', 
	               ), 
	     'award_icon'  => array( 
			       'label' => esc_html__('Services Icon', 'selfintro'),
			       'desc' => esc_html__('Upload Services Icon Here.', 'selfintro'),
			        'type' => 'upload', 
			        ),   
			      ), 
	            ),				 
		);