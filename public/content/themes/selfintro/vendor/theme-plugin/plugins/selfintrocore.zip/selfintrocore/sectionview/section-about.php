<?php  
if(function_exists( 'fw_get_db_settings_option' )):	
	$selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?> 
<div class="prt_about_wrapper prt_toppadder115">
	<?php 
	$about_image = '';
    if(!empty($selfintro_data['about_image']['url'])):
        $about_image = $selfintro_data['about_image']['url'];
    endif;
    $heading = '';
    if(!empty($selfintro_data['heading'])):
        $heading = $selfintro_data['heading']; 
    endif; 
    $heading_sub = '';
    if(!empty($selfintro_data['heading_sub'])):
        $heading_sub = $selfintro_data['heading_sub'];
    endif;
    $descreption = '';
    if(!empty($selfintro_data['about_desc'])):
        $descreption = $selfintro_data['about_desc'];
    endif;
    $resume_download = '';
    if(!empty($selfintro_data['resume_download'])):
        $resume_download = $selfintro_data['resume_download'];
    endif;
    $hire_me = '';
    if(!empty($selfintro_data['hire_me'])):
        $hire_me = $selfintro_data['hire_me'];
    endif;
	 ?>
	<div class="prt_close_wrapper">
		<i class="fa fa-chevron-down prt_close"></i>
	</div>
	<div class="container">
		<div class="row">
			<div class="prt_about_info prt_bottompadder80">
				    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				        <?php if(!empty($about_image)): ?>
						   <div class="prt_about_img">
						 	 <img src="<?php echo esc_url($about_image); ?>" alt="<?php esc_html_e('About','selfintro'); ?>">
						   </div>
						<?php endif; ?>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prt_heading_wrapper_2">
							<div class="prt_heading prt_toppadder50">
								<h1><?php echo esc_html($heading); ?></h1>
								<?php 
								 if($typedsettings == 'on'): ?>
									<div class="typed_strings_about">
									 <p class="write_about" data-strings-about="<?php echo esc_html($heading_sub); ?>"><?php echo esc_html($heading_sub); ?></p>
									</div> 
								<?php else: ?>  
								  <p><?php echo esc_html($heading_sub); ?></p>
								<?php endif; ?>
							</div> 
						</div>
						<?php if(!empty($descreption)): ?>
						<div class="prt_about_details">
							<p><?php printf($descreption); ?></p>
							<?php 
							if(!empty($resume_download)): ?>
							<a href="<?php echo esc_url($resume_download); ?>" class="prt_btn">
							     <?php esc_html_e('Download Resume','selfintro'); ?></a> 
							<?php 
							endif;
							if(!empty($hire_me)):
							   echo '<a href="'.esc_url($hire_me).'" class="prt_btn">'.esc_html__('Hire Me','selfintro').'</a>';
							endif;
							?>
						</div> 
						<?php endif; ?>
					</div>
				</div>
                <div class="prt_about_edulearn_wrapper prt_bottompadder115">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="prt_heading_wrapper">
						<?php 
						$education_heading = '';
                        if(!empty($selfintro_data['education_heading'])):
                          $education_heading = $selfintro_data['education_heading'];
                        endif;
                        $education_sub_heading = '';
                        if(!empty($selfintro_data['education_sub_heading'])):
                            $education_sub_heading = $selfintro_data['education_sub_heading'];
                        endif;
                        $education_number = '';
                        if(!empty($selfintro_data['education_number'])):
                        $education_number = $selfintro_data['education_number'];
                        endif;
                         $experience_heading = '';
                            if(!empty($selfintro_data['experience_heading'])):
                              $experience_heading = $selfintro_data['experience_heading'];
                            endif;
                            $experience_sub_heading = '';
                            if(!empty($selfintro_data['experience_sub_heading'])):
                                $experience_sub_heading = $selfintro_data['experience_sub_heading'];
                            endif;
                            $experience_number = '';
                            if(!empty($selfintro_data['experience_number'])):
                            $experience_number = $selfintro_data['experience_number'];
                            endif;
                        if(!empty($education_heading)):
						    echo '<div class="prt_heading">
    							  <h1>'.esc_html($education_heading).'</h1>';
								  if($typedsettings == 'on'): 
								    echo'<div class="typed_strings_education">
									      <p class="write_education" data-strings-education="'.esc_html($education_sub_heading).'">'.esc_html($education_sub_heading).'</p>
								        </div>';
									else: 
									    echo '<p>'.esc_html($education_sub_heading).'</p>';
									endif;
    						echo '</div>'; 
					    endif;
						?>
						</div>
						<div class="prt_about_learnsection">
							<div class="row">
							    <?php
							    $eventodd = 0;
							    $args = array( 'post_type' => 'education', 
			                                 'posts_per_page'=>$education_number     );
                                $selfintro_query = new WP_Query($args); 
		                    	if($selfintro_query->have_posts()):
		                         while($selfintro_query->have_posts()):
		                            $selfintro_query->the_post();
		                        $selfintro_data = '';
		                        if(function_exists( 'fw_get_db_post_option' )):	
                                   $selfintro_data = fw_get_db_post_option(get_the_ID()); 
                                endif;
                                $city = '';
                                if(!empty($selfintro_data['city'])):
                                   $city = $selfintro_data['city'];
                                endif;   
                                $year = '';
                                if(!empty($selfintro_data['year'])):
                                   $year = $selfintro_data['year'];
                                endif; 
		                        if ($eventodd % 2 == 0):
							    ?>
							    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-6 col-md-offset-6 col-sm-offset-0 col-xs-offset-0">
									<div class="prt_about_learnbox_right">
									    <?php if(!empty($year)): ?>
										<div class="prt_about_learnbox_year">
										     <h1><?php echo esc_html($year);?></h1>
										</div>
										<?php endif; ?>
										<div class="prt_about_learnbox_info">
											<h4><?php the_title(); ?></h4>
											<?php if(!empty($city)): ?>
											 <span>
											   <?php echo esc_html($city);?>
											 </span>
											<?php endif; ?>
											<p><?php echo selfintro_the_excerpt(200); ?></p>
										</div>
									</div>
								</div> 
								<?php else: ?>
								<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
									<div class="prt_about_learnbox_left">
									    <?php if(!empty($year)): ?>
										<div class="prt_about_learnbox_year">
										  <h1><?php echo esc_html($year);?></h1>
										</div>
										<?php endif; ?>
										<div class="prt_about_learnbox_info">
											<h4><?php the_title(); ?></h4>
											<?php if(!empty($city)): ?>
											 <span>
											   <?php echo esc_html($city);?>
											 </span>
											<?php endif; ?>
									    <p><?php 
									        echo selfintro_the_excerpt(200);?></p>  
										</div>
									</div>
								</div>
							   <?php 
							    endif;
							    $eventodd++;
							 endwhile;	
		                 	endif;
			                wp_reset_postdata();
							?>
							</div>
						</div>
					</div>
				</div>
				<div class="prt_about_experience_wrapper prt_bottompadder60">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="prt_heading_wrapper">
						   <?php 
						   if(!empty($experience_heading)):
							echo '<div class="prt_heading">
								   <h1>'.esc_html($experience_heading).'</h1>';
								   if($typedsettings == 'on'): 
								    echo'<div class="typed_strings_experience">
									      <p class="write_experience" data-strings-experience="'.esc_html($experience_sub_heading).'">'.esc_html($experience_sub_heading).'</p>
								        </div>';
									else: 
									    echo '<p>'.esc_html($experience_sub_heading).'</p>';
									endif;
							echo '</div>';
							endif;
							?>
						</div>
						<div class="prt_about_experience">
							<div class="row">
							<?php
							$args = array('post_type' => 'experience', 
			                             'posts_per_page'=>$experience_number);
                                $selfintro_query = new WP_Query($args); 
		                    	if($selfintro_query->have_posts()):
		                         while($selfintro_query->have_posts()):
		                            $selfintro_query->the_post();
		                        $selfintro_data = '';
		                        if(function_exists( 'fw_get_db_post_option' )):	
                                   $selfintro_data = fw_get_db_post_option(get_the_ID()); 
                                endif;
                                $city = '';
                                if(!empty($selfintro_data['city'])):
                                   $city = $selfintro_data['city'];
                                endif;   
                                $year = '';
                                if(!empty($selfintro_data['year'])):
                                   $year = $selfintro_data['year'];
                                endif; 
                                $time_priode = '';
                                if(!empty($selfintro_data['time_prode'])):
                                   $time_priode = $selfintro_data['time_prode'];
                                endif; 
		                       ?>    
								<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
									<div class="prt_about_experiencebox">
										<div class="prt_about_experience_year">
										 <?php if(!empty($year)): ?>
										 <h1><?php echo esc_html($year); ?></h1>
										<?php 
										 endif;
										 if(!empty($time_priode)): ?>
									     <h4><?php echo esc_html($time_priode); ?></h4>
									    <?php endif; ?>
										</div>
										<div class="prt_about_experience_info">
										  <h4><?php the_title(); ?></h4>
										  <?php if(!empty($city)): ?>
										   <span>
											<?php echo esc_html($city); ?></span>
										 <?php endif; ?>
									     <p><?php echo selfintro_the_excerpt(250); ?></p> 
										</div>
									</div>
								</div>
						    	<?php 
							    endwhile;	
		                 	  endif;
			                  wp_reset_postdata();
							?>
							</div>
						</div>
					</div>
				</div>
				<div class="prt_profile_info">
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prt_profile_slider">
							<div class="owl-carousel owl-theme">
						    <?php
					        if(function_exists( 'fw_get_db_settings_option' )):
					          $selfintro_data = fw_get_db_settings_option();  
                            endif; 
                            $profiles_logo = '';
                            if(!empty($selfintro_data['profiles_slider'])):
                            $profiles_logo = $selfintro_data['profiles_slider'];
                            endif;
                            if(!empty($profiles_logo)):
                            foreach($profiles_logo as $values):
                            if(!empty($values['title'])):
                                if(!empty($values['profile_image']['url'])):
                                $attachment_id = $values['profile_image']['attachment_id'];
                                   $selfintro_logoimage = wp_get_attachment_url($attachment_id, 'full');
                                  $logoimage = selfintro_resize($selfintro_logoimage, 70, 70); 
                             endif; 
							 $profiles_url = '';
								if(!empty($values['profiles_url'])):
								  $profiles_url = $values['profiles_url'];
								endif;
                             ?>
                            <div class="item">
                              <a href="<?php echo esc_url($profiles_url); ?>"><img src="<?php echo esc_url($logoimage); ?>"  alt="<?php echo esc_html($values['title']); ?>"/></a>
							  <h4><?php echo esc_html($values['title']); ?></h4>
							</div>  
							<?php 
							  endif;
							 endforeach;
							endif;
							?>
						   </div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					    <div class="prt_heading_wrapper_2">
						<?php 
						$profiles_title = '';
                        if(!empty($selfintro_data['profiles_title'])):
                         $profiles_title = $selfintro_data['profiles_title'];
                        endif;
                        $profiles_sub_title = '';
                        if(!empty($selfintro_data['profiles_sub_title'])):
                         $profiles_sub_title = $selfintro_data['profiles_sub_title'];
                        endif;
                        $profiles_desc = '';
                        if(!empty($selfintro_data['profiles_desc'])):
                         $profiles_desc = $selfintro_data['profiles_desc'];
                        endif;
                        ?>
						<div class="prt_heading">
							<h1><?php echo esc_html($profiles_title); ?></h1>
							<?php 
							if($typedsettings == 'on'): 
								echo'<div class="typed_strings_profiles">
									  <p class="write_profiles" data-strings-profiles="'.esc_html($profiles_sub_title).'">'.esc_html($profiles_sub_title).'</p>
								    </div>';
							else: 
								echo '<p>'.esc_html($profiles_sub_title).'</p>';
							endif;
							?> 
						</div>
						</div>
						<div class="prt_profile_details">
							<p><?php printf($profiles_desc); ?></p>
						</div>
					</div>
				</div>
			<div class="prt_blog_wrapper prt_toppadder110">
               <div class="container">
                  <div class="row">
                   <?php
                   $blog_heading = '';
                   if(!empty($selfintro_data['blog_heading'])):
                      $blog_heading =  $selfintro_data['blog_heading'];
                   endif;
                   $blog_sub_heading = '';
                   if(!empty($selfintro_data['blog_sub_heading'])):
                       $blog_sub_heading =  $selfintro_data['blog_sub_heading'];
                   endif;
                   $show_blog = '';
                   if(!empty($selfintro_data['show_blog'])):
                       $show_blog =  $selfintro_data['show_blog'];
                   endif;
				   if(!empty($blog_heading) || !empty($blog_sub_heading)): ?>
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="prt_heading_wrapper">
					   <div class="prt_heading">
					    <?php if(!empty($blog_heading)): ?>
						   <h1><?php printf($blog_heading); ?></h1>
						<?php 
						endif;
						if(!empty($blog_sub_heading)): 
						    if($typedsettings == 'on'): 
							    echo'<div class="typed_strings_blog">
								    <p class="write_blog" data-strings-blog="'.esc_html($blog_sub_heading).'">'.esc_html($blog_sub_heading).'</p></div>';
						    else:  
						        echo '<p>'.esc_html($blog_sub_heading).'</p>';
					        endif; 
						endif;
						?>
					 </div>
				  </div>
               </div> 
              <?php 
             endif;
            $selfintro_thumb_w =360;
			$selfintro_thumb_h =245;
            $args = array(
                   'post_type' =>'post',
				   'posts_per_page' =>$show_blog ,
                   'post_status' =>'publish',
                  );
            $self_query = new WP_Query($args);
            if($self_query->have_posts()):
                while($self_query->have_posts()): $self_query->the_post();
				if(has_post_thumbnail(get_the_ID())):
                   $self_attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()), 'full');
			           $thum_image = selfintro_resize($self_attachment_url, $selfintro_thumb_w, $selfintro_thumb_h, true);
			    endif;	
			 ?>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="prt_blog_section">
                    <?php if(!empty($thum_image)): ?>
                    <div class="blog_img">
                       <img src="<?php echo esc_url($thum_image); ?>" alt="<?php echo get_the_title(); ?>" title="<?php echo get_the_title(); ?>" class="img-responsive">
                    </div>  
                    <?php endif; ?>
                    <div class="blog_text">
                       <h4><a href="<?php echo esc_url(get_the_permalink(get_the_ID(get_the_ID()))); ?>"><?php the_title(); ?></a></h4>
                        <p class="post_meta">
                          <?php selfintro_posted_on(); ?>
		                </p>  
                        <p><?php echo selfintro_the_excerpt(250); ?></p>
                        <a href="<?php echo esc_url(get_the_permalink(get_the_ID()));?>" class="prt_btn"><?php esc_html_e('read more','industry'); ?></a>
                    </div>    
                </div> 
            </div>
            <?php
             endwhile;
             wp_reset_postdata();
            endif;
            ?>
           </div>    
          </div>    
         </div>
		</div> 
	  </div> 
	<?php selfintro_footer_copyright(); ?>	
  </div>  