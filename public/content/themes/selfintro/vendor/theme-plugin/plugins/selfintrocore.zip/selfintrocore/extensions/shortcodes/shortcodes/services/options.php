<?php if(!defined('FW')) {
	die( 'Forbidden' );
}
$options = array(
'services_heading'  => array( 
			'label' => esc_html__('Services Heading', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			), 	 
'services_sub_heading'  => array( 
			'label' => esc_html__('Services Sub Heading', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			),
'services_about_images' =>array( 
		      'type' => 'addable-popup',
		      'value' => array(
			   array(
				    'services_about_images' => 'Services About Images',
			        ),
	     	     ),
		      'label' => esc_html__('Add Services About Images', 'selfintro'),
		      'template' => '{{- objectives_title }}',
		      'popup-title' => null, 
		      'size' => 'small', // small, medium, large
		      'limit' => 0, // limit the number of popup`s that can be added
	      	  'add-button-text' => esc_html__('Add', 'selfintro'), 
		      'sortable' => true,
		      'popup-options' => array(
		      'about_images' => array( 
			       'label' => esc_html__('Services About Images', 'selfintro'),
			       'desc' => esc_html__('Upload Services About Images Here.', 'selfintro'),
			        'type' => 'upload', 
			       ),   
			      ), 
	            ),
'our_services' =>array( 
		      'type' => 'addable-popup',
		      'value' => array(
			   array(
				    'services' => 'Services Us Detail',
			        ),
	     	     ),
		      'label' => esc_html__('Add Services', 'selfintro'),
		      'template' => '{{- objectives_title }}',
		      'popup-title' => null,
		      'size' => 'small', // small, medium, large
		      'limit' => 0, // limit the number of popup`s that can be added
	      	  'add-button-text' => esc_html__('Add', 'selfintro'), 
		      'sortable' => true,
		      'popup-options' => array(
		          'title' => array(
		          'label' => esc_html__('Title', 'selfintro'),
		           'type' => 'text', 
	               ),
	           'descreption'  => array( 
				   'label' => esc_html__('Descreption', 'selfintro'),
				   'type' => 'wp-editor',
			   	   'value' => '',
				   'desc' => esc_html__('', 'selfintro'),
				   'media_buttons' => false,
			       'wpautop' => false,
			      ),	   
	           'services_icon'  => array( 
			       'label' => esc_html__('Services Icon', 'selfintro'),
			       'desc' => esc_html__('Upload Services Icon Here.', 'selfintro'),
			        'type' => 'upload', 
			     ),   
			), 
	  ),			 		
 );			
?>