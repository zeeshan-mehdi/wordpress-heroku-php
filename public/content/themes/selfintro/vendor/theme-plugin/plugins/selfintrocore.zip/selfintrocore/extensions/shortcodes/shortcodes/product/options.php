<?php 
if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;
$options = array(
  'heading' => array(
		'type'  => 'text',
		'label' => esc_html__('Enter Heading', 'industry'),
	   ),
  'sub_heading' => array(
		'type'  => 'text',
		'label' => esc_html__('Enter Sub Heading', 'industry'),
	      ),
   'producted_show' => array(
		'type'  => 'text',
		'label' => esc_html__('Enter Number Producted', 'industry'),
	      ),
           
    );    