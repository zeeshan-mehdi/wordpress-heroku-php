<?php if(!defined('FW')) {
	die( 'Forbidden' );
}
$education_heading = '';
if(!empty($atts['education_heading'])):
   $education_heading = $atts['education_heading'];
endif;
$education_sub_heading = '';
if(!empty($atts['education_sub_heading'])):
   $education_sub_heading = $atts['education_sub_heading'];
endif;
$education_number = '';
if(!empty($atts['education_number'])):
   $education_number = $atts['education_number'];
endif; 
if(function_exists( 'fw_get_db_settings_option' )):	
   $selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?>   
<div class="container">
	<div class="row">
	    <div class="prt_about_edulearn_wrapper">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="prt_heading_wrapper">
						   <?php 
						    if(!empty($education_heading)):
							    echo '<div class="prt_heading">
									  <h1>'.esc_html($education_heading).'</h1>';
						        if($typedsettings == 'on'): 
								    echo'<div class="typed_strings_education">
									      <p class="write_education" data-strings-education="'.esc_html($education_heading).'">'.esc_html($education_heading).'</p>
								        </div>';
						        else: 
							       echo '<p>'.esc_html($education_sub_heading).'</p>';
								endif;
							echo '</div>';
							endif;
						   ?>
						</div>
						<div class="prt_about_learnsection">
							<div class="row">
							 <?php
							    $eventodd = 0;
							    $args = array( 'post_type' => 'education', 
			                                 'posts_per_page'=>$education_number     );
                                $selfintro_query = new WP_Query($args); 
		                    	if($selfintro_query->have_posts()):
		                         while($selfintro_query->have_posts()):
		                            $selfintro_query->the_post();
		                        $selfintro_data = '';
		                        if(function_exists( 'fw_get_db_post_option' )):	
                                   $selfintro_data = fw_get_db_post_option(get_the_ID()); 
                                endif;
                                $city = '';
                                if(!empty($selfintro_data['city'])):
                                   $city = $selfintro_data['city'];
                                endif;   
                                $year = '';
                                if(!empty($selfintro_data['year'])):
                                   $year = $selfintro_data['year'];
                                endif; 
		                        if ($eventodd % 2 == 0):
							    ?>
							    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-6 col-md-offset-6 col-sm-offset-0 col-xs-offset-0">
									<div class="prt_about_learnbox_right">
									    <?php if(!empty($year)): ?>
										<div class="prt_about_learnbox_year">
										     <h1><?php echo esc_html($year);?></h1>
										</div>
										<?php endif; ?>
										<div class="prt_about_learnbox_info">
											<h4><?php the_title(); ?></h4>
											<?php if(!empty($city)): ?>
											 <span>
											   <?php echo esc_html($city);?>
											 </span>
											<?php endif; ?>
											<p><?php echo selfintro_the_excerpt(200); ?></p>
										</div>
									</div>
								</div>
								<?php else: ?>
								<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
									<div class="prt_about_learnbox_left">
									    <?php if(!empty($year)): ?>
										<div class="prt_about_learnbox_year">
										  <h1><?php echo esc_html($year);?></h1>
										</div>
										<?php endif; ?>
										<div class="prt_about_learnbox_info">
											<h4><?php the_title(); ?></h4>
											<?php if(!empty($city)): ?>
											 <span>
											   <?php echo esc_html($city);?>
											 </span>
											<?php endif; ?>
									    <p><?php 
									        echo selfintro_the_excerpt(200);?></p>  
										</div>
									</div>
								</div>
							   <?php 
							    endif;
							    $eventodd++;
							 endwhile;	
		                 	endif;
			                wp_reset_postdata();
							?>
							</div>
						</div>
					</div>
				</div>
		</div>
</div>