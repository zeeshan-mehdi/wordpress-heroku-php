<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$experience_heading = '';
if(!empty($atts['experience_heading'])):
   $experience_heading = $atts['experience_heading'];
endif;
$experience_sub_heading = '';
if(!empty($atts['experience_sub_heading'])):
   $experience_sub_heading = $atts['experience_sub_heading'];
endif;
$experience_number = '';
if(!empty($atts['experience_number'])):
   $experience_number = $atts['experience_number'];
endif; 
if(function_exists( 'fw_get_db_settings_option' )):	
   $selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?>  
<div class="container">
	 <div class="row">
	    <div class="prt_about_experience_wrapper prt_bottompadder60">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="prt_heading_wrapper">
						   <?php 
							if(!empty($experience_heading)):
								echo '<div class="prt_heading">
									   <h1>'.esc_html($experience_heading).'</h1>';
									if($typedsettings == 'on'): 
								    echo'<div class="typed_strings_experience">
									      <p class="write_experience" data-strings-experience="'.esc_html($experience_sub_heading).'">'.esc_html($experience_sub_heading).'</p>
								        </div>';
									else: 
									   echo '<p>'.esc_html($experience_sub_heading).'</p>';
									endif;
									echo '</div>';
							    endif;
						    ?>
						</div>
						<div class="prt_about_experience">
							<div class="row">
								<?php
							$args = array('post_type' => 'experience', 
			                             'posts_per_page'=>$experience_number);
                                $selfintro_query = new WP_Query($args); 
		                    	if($selfintro_query->have_posts()):
		                         while($selfintro_query->have_posts()):
		                            $selfintro_query->the_post();
		                        $selfintro_data = '';
		                        if(function_exists( 'fw_get_db_post_option' )):	
                                   $selfintro_data = fw_get_db_post_option(get_the_ID()); 
                                endif;
                                $city = '';
                                if(!empty($selfintro_data['city'])):
                                   $city = $selfintro_data['city'];
                                endif;   
                                $year = '';
                                if(!empty($selfintro_data['year'])):
                                   $year = $selfintro_data['year'];
                                endif; 
                                $time_priode = '';
                                if(!empty($selfintro_data['time_prode'])):
                                   $time_priode = $selfintro_data['time_prode'];
                                endif; 
		                       ?>    
								<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
									<div class="prt_about_experiencebox">
										<div class="prt_about_experience_year">
										 <?php if(!empty($year)): ?>
										 <h1><?php echo esc_html($year); ?></h1>
										<?php 
										 endif;
										 if(!empty($time_priode)): ?>
									     <h4><?php echo esc_html($time_priode); ?></h4>
									    <?php endif; ?>
										</div>
										<div class="prt_about_experience_info">
										  <h4><?php the_title(); ?></h4>
										  <?php if(!empty($city)): ?>
										   <span>
											<?php echo esc_html($city); ?>        </span>
										 <?php endif; ?>
									     <p><?php echo selfintro_the_excerpt(250); ?></p> 
										</div>
									</div>
								</div>
						    	<?php 
							    endwhile;	
		                 	  endif;
			                  wp_reset_postdata();
							?>
							</div>
						</div>
					</div>
				</div>
		</div>
</div> 