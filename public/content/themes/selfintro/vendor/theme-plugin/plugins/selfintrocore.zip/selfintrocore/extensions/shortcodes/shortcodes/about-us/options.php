<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$options = array(
'heading'  => array( 
	'about_label' => esc_html__('Heading', 'selfintro'),
	'type' => 'text',
	'value' => '',
	'desc' => esc_html__('', 'selfintro'),
	), 
'heading_sub'  => array( 
	'about_label' => esc_html__('Sub Heading', 'selfintro'),
	'type' => 'text',
	'value' => '',
	'desc' => esc_html__('', 'selfintro'),
	),
'about_image'  => array( 
		'label' => esc_html__('About Image', 'selfintro'),
		'desc' => esc_html__('Upload about image Here.', 'selfintro'),
		'type' => 'upload', 
	  ),	
'about_desc'  => array( 
		'label' => esc_html__('Description', 'selfintro'),
		'type' => 'wp-editor',
		'value' => '',
		'desc' => esc_html__('', 'selfintro'),
		'media_buttons' => false,
		'wpautop' => false,
	   ),	
'resume_download_text'  => array( 
		'about_label' => esc_html__('Resume Download Button Text', 'selfintro'),
		'type' => 'text',
		'value' => '',
		 'desc' => esc_html__('', 'selfintro'),
		 ),
'resume_download'  => array( 
		'about_label' => esc_html__('Resume Download File Link', 'selfintro'),
		'type' => 'text',
		'value' => '',
		 'desc' => esc_html__('', 'selfintro'),
		 ),
'hire_me'  => array( 
		 'about_label' => esc_html__('Hire Me Url', 'selfintro'),
		 'type' => 'text',
		 'value' => '',
		 'desc' => esc_html__('', 'selfintro'),
	   ), 			
);