<?php 
if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;
$options = array(
    'heading' => array(
			    'type'  => 'text',
				'label' => esc_html__('Enter Heading', 'selfintro'),
				),
	'map_address' => array(
		           'label' => esc_html__('Google Map Address', 'selfintro'),
		           'type' => 'text',
	              ),
	'longitude' => array(
		           'label' => esc_html__('Longitude', 'selfintro'),
		           'type' => 'text',
	              ), 
    'latitude' => array(
		           'label' => esc_html__('Latitude', 'selfintro'),
		           'type' => 'text',
	               ),
	'map_zoom' => array(
			    'type'  => 'text',
				'label' => esc_html__('Enter Google Map Zoom', 'selfintro'),
				),
	'geometry' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Geometry Color Set', 'selfintro'),
            'desc'  => __('Map Geometry Color', 'selfintro'),
           ),
   'labelstextstroke' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Labelstextstroke Color Set', 'selfintro'),
            'desc'  => __('Map Labelstextstroke Color', 'selfintro'),
           ),
	'labelstextfill' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Labelstextfill Color Set', 'selfintro'),
            'desc'  => __('Map Labelstextfill Color', 'selfintro'),
           ),
	'poi_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Poi Color Set', 'selfintro'),
            'desc'  => __('Map Labelstextfill Color', 'selfintro'),
           ),
	'locality_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Locality Color Set', 'selfintro'),
            'desc'  => __('Map Locality Color', 'selfintro'),
           ),
	'poi_park_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Poi Park Color Set', 'selfintro'),
            'desc'  => __('Map Poi Park Color', 'selfintro'),
           ),
	'road_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Road Color Set', 'selfintro'),
            'desc'  => __('Map Road Color', 'selfintro'),
           ),
	'text_fill_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Text Fill Color Set', 'selfintro'),
            'desc'  => __('Map Text Fill Color', 'selfintro'),
           ),
	'road_highway_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Road Highway Color Set', 'selfintro'),
            'desc'  => __('Map Road Highway Color', 'selfintro'),
           ),
	'road_stroke_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Road Stroke Color Set', 'selfintro'),
            'desc'  => __('Map Road Stroke Color', 'selfintro'),
           ),
	'road_text_fill_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Road Text Fill Color Set', 'selfintro'),
            'desc'  => __('Map Road Text Fill Color', 'selfintro'),
           ), 
	'transit_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Transit Color Set', 'selfintro'),
            'desc'  => __('Map Transit Color', 'selfintro'),
           ),
	'transitstation_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Transit Station Color Set', 'selfintro'),
            'desc'  => __('Map Transit Station Color', 'selfintro'),
           ),
	'water_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Water Color Set', 'selfintro'),
            'desc'  => __('Map Water Color', 'selfintro'),
           ),
	'water_text_fill_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Water Text Fill Color Set', 'selfintro'),
            'desc'  => __('Map Water Color', 'selfintro'),
           ),
	'water_text_stroke_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Water Text Fill Color Set', 'selfintro'),
            'desc'  => __('Map Water Color', 'selfintro'),
           ),
				  
);    	 