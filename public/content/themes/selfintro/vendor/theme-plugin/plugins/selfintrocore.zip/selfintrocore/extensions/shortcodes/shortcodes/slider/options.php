<?php if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;
if ( class_exists( 'RevSlider' ) ) {
global $wpdb;
$slidername = '';
$tablename = $wpdb->prefix.'revslider_sliders';
$results = $wpdb->get_results('SELECT * FROM '.$tablename);
foreach($results as $values):
   $slidername[$values->alias] = $values->alias;
endforeach;  
$options = array(
	'rev_alias' => array(
        'type'  => 'select',
        'value' => '',
        'attr'  => array('class' => 'custom-class', 'data-foo' => 'bar' ),
        'label' => __('Select Revslider Sliders', 'selfintro'),
        'desc'  => __('Select Revslider Sliders','selfintro'), 
        'help'  => __('Select Revslider Sliders','selfintro'), 
        'choices' => $slidername, 
     ), 
);  
} 