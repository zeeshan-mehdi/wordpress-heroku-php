<?php if(!defined('FW')) {
	die('Forbidden');
}
$contact_us_heading = '';
if(!empty($atts['contact_us_heading'])):
   $contact_us_heading = $atts['contact_us_heading'];
endif;
$contact_us_sub_heading = '';
if(!empty($atts['contact_us_sub_heading'])):
   $contact_us_sub_heading = $atts['contact_us_sub_heading'];
endif;
$form_heading = '';
if(!empty($atts['form_heading'])):
    $form_heading = $atts['form_heading']; 
endif;
$form_shortcode = '';
if(!empty($atts['form_shortcode'])):
  $form_shortcode = $atts['form_shortcode'];
endif;
$googlemap_ifram = '';
if(!empty($atts['googlemap_ifram'])):
    $googlemap_ifram = $atts['googlemap_ifram'];  
endif;
$contactus_detail = '';
if(!empty($atts['contactus_detail'])):
   $contactus_detail = $atts['contactus_detail'];
endif;
$map_address = '';
if(!empty($atts['map_address'])):
	$heading = $atts['map_address'];
endif;
$longitude = -73.945;
if(!empty($atts['longitude'])):
	$longitude = $atts['longitude'];
endif;
$latitude =40.674;
if(!empty($atts['latitude'])):
	$latitude = $atts['latitude'];
endif;
$map_zoom = 12;
if(!empty($atts['map_zoom'])):
	$latitude = $atts['map_zoom'];
endif;
$geometry = '';
if(!empty($atts['geometry'])):
	$geometry = $atts['geometry'];
endif;
$labelstextstroke = '';
if(!empty($atts['labelstextstroke'])):
	$labelstextstroke = $atts['labelstextstroke'];
endif;
$labelstextfill = '';
if(!empty($atts['labelstextfill'])):
	$labelstextfill = $atts['labelstextfill'];
endif;
$labelstextstroke = '';
if(!empty($atts['labelstextstroke'])):
	$labelstextstroke = $atts['labelstextstroke'];
endif;
$poi_color = '';
if(!empty($atts['poi_color'])):
	$poi_color = $atts['poi_color'];
endif;
$locality_color = '';
if(!empty($atts['locality_color'])):
	$locality_color = $atts['locality_color'];
endif;
$poi_park_color = '';
if(!empty($atts['poi_park_color'])):
	$poi_park_color = $atts['poi_park_color'];
endif;
$road_color = '';
if(!empty($atts['road_color'])):
	$road_color = $atts['road_color'];
endif;
$text_fill_color = '';
if(!empty($atts['text_fill_color'])):
	$text_fill_color = $atts['text_fill_color'];
endif;
$road_highway_color = '';
if(!empty($atts['road_highway_color'])):
	$road_highway_color = $atts['road_highway_color'];
endif;
$road_stroke_color = '';
if(!empty($atts['road_stroke_color'])):
	$road_highway_color = $atts['road_stroke_color'];
endif;
$road_text_fill_color = '';
if(!empty($atts['road_text_fill_color'])):
	$road_text_fill_color = $atts['road_text_fill_color'];
endif;
$transit_color = '';
if(!empty($atts['transit_color'])):
	$transit_color = $atts['transit_color'];
endif;
$transitstation_color = '';
if(!empty($atts['transitstation_color'])):
	$transitstation_color = $atts['transitstation_color'];
endif;
$water_color = '';
if(!empty($atts['water_color'])):
	$water_color = $atts['water_color'];
endif;
$water_text_fill_color = '';
if(!empty($atts['water_text_fill_color'])):
	$water_text_fill_color = $atts['water_text_fill_color'];
endif;
$water_text_stroke_color = '';
if(!empty($atts['water_text_stroke_color'])):
	$water_text_stroke_color = $atts['water_text_stroke_color'];
endif;
if(function_exists( 'fw_get_db_settings_option' )):	
   $selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?> 
<div class="container">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="prt_heading_wrapper">
			  <?php
			   if(!empty($contact_us_heading)):
					echo '<div class="prt_heading">
							<h1>'.esc_html($contact_us_heading).'</h1>';
							if($typedsettings == 'on'): 
							    echo'<div class="typed_strings_contact">
									<p class="write_contact" data-strings-contact="'.esc_html($contact_us_sub_heading).'">'.esc_html($contact_us_sub_heading).'</p></div>';
							else:  
								echo '<p>'.esc_html($contact_us_sub_heading).'</p>';
							endif;
					echo '</div>';
				endif;
				?>
				</div>
			</div>
			<div class="prt_contact_box">
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					   <div class="prt_contact_info">
						    <?php if(!empty($form_heading)): ?>
							   <h1><?php echo esc_html($form_heading); ?></h1>
							<?php endif; ?>
							<div class="prt_contact_form">
								<div class="row">
								 <?php echo do_shortcode($form_shortcode); ?>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prt_contact_map">
							<?php
							   if(!empty($googlemap_ifram)): 
									print($googlemap_ifram);
								else:
								?>
								<div class="sl_color_map">
                                  <div id="map"></div> 
                                </div>
                             <script>
				             // Styles a map in night mode.
						   var map = new google.maps.Map(document.getElementById('map'), {
						    center: {lat: <?php echo esc_js($latitude); ?>, lng: <?php echo esc_js($longitude); ?>},
						    zoom: <?php echo esc_js($map_zoom); ?>,
						    styles: [
					            {elementType: 'geometry', stylers: [{color: '#242f3e'}]},
					            {elementType: 'labels.text.stroke', stylers: [{color: '#242f3e'}]},
					            {elementType: 'labels.text.fill', stylers: [{color: '#746855'}]},
					            {
					              featureType: 'administrative.locality',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '#d59563'}]
					            },
					            {
					              featureType: 'poi',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '#d59563'}]
					            },
					            {
					              featureType: 'poi.park',
					              elementType: 'geometry',
					              stylers: [{color: '#263c3f'}]
					            },
					            {
					              featureType: 'poi.park',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '#6b9a76'}]
					            },
					            {
					              featureType: 'road',
					              elementType: 'geometry',
					              stylers: [{color: '#38414e'}]
					            },
					            {
					              featureType: 'road',
					              elementType: 'geometry.stroke',
					              stylers: [{color: '#212a37'}]
					            },
					            {
					              featureType: 'road',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '#9ca5b3'}]
					            },
					            {
					              featureType: 'road.highway',
					              elementType: 'geometry',
					              stylers: [{color: '#746855'}]
					            },
					            {
					              featureType: 'road.highway',
					              elementType: 'geometry.stroke',
					              stylers: [{color: '#1f2835'}]
					            },
					            {
					              featureType: 'road.highway',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '#f3d19c'}]
					            },
					            {
					              featureType: 'transit',
					              elementType: 'geometry',
					              stylers: [{color: '#2f3948'}]
					            },
					            {
					              featureType: 'transit.station',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '#d59563'}]
					            },
					            {
					              featureType: 'water',
					              elementType: 'geometry',
					              stylers: [{color: '#17263c'}]
					            },
					            {
					              featureType: 'water',
					              elementType: 'labels.text.fill',
					              stylers: [{color: '#515c6d'}]
					            },
					            {
					              featureType: 'water',
					              elementType: 'labels.text.stroke',
					              stylers: [{color: '#17263c'}]
					            }
					          ]
						});
                      </script> 
						<?php
						endif;
						?>
						</div>
					</div>
				</div> 
				<div class="prt_contact_details">
				 <?php 
				  if(!empty($contactus_detail)):
				      foreach($contactus_detail as $addinfo):
				          $cs_bg_image = '';
				          if(!empty($addinfo['add_bg_image']['url'])):
				           $cs_bg_image = $addinfo['add_bg_image']['url'];
				          endif;
				          $bg_image_url = '';
                        if(!empty($cs_bg_image)):
                            $bg_image_url = 'background-image:url(' .$cs_bg_image. ');';
                        endif;
                        $title = '';
                        if(!empty($addinfo['title'])):
                           $title = $addinfo['title'];
                        endif;
                        $address_info = '';
                        if(!empty($addinfo['address_info'])):
                           $address_info = $addinfo['address_info'];
                        endif;
                        if(!empty($address_info)):
                         ?>
				         <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
    					    <div class="prt_contact_details_box details_box1" style=<?php printf($bg_image_url); ?>>
    						    <?php if(!empty($title)): ?>
    						       <h4><?php echo esc_html($title); ?></h4>
    							<?php
    							endif;
    							print($address_info); ?>
    						 </div>
					     </div>
					   <?php
					     endif;
					  endforeach;
					endif;
				 ?> 
		   </div>
	 </div>
</div>  