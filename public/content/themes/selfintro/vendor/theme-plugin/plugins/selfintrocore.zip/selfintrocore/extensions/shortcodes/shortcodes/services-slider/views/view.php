<?php if(!defined('FW')):
	  die('Forbidden');
     endif;
$services_heading = ''; 
if(!empty($atts['services_heading'])):
    $services_heading = $atts['services_heading'];
endif;
$services_sub_heading = '';
if(!empty($atts['services_sub_heading'])):
   $services_sub_heading = $atts['services_sub_heading'];
endif;
$numberof_services = '';
if(!empty($atts['numberof_services'])):
   $numberof_services = $atts['numberof_services'];
endif;
if(function_exists( 'fw_get_db_settings_option' )):	
   $selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif; 		  
?>
<div class="self_service_slider">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<?php if(!empty($services_heading)): ?>
			<div class="prt_heading_wrapper">
			  <div class="prt_heading">
				 <h1><?php echo esc_html($services_heading); ?></h1>
				<?php 
				if($typedsettings == 'on'): 
					echo'<div class="typed_strings_services">
						<p class="write_services" data-strings-services="'.esc_html($services_sub_heading).'">'.esc_html($services_sub_heading).'</p></div>';
				else:  
					echo '<p>'.esc_html($services_sub_heading).'</p>';
				endif;
				?> 
			  </div>
			</div>
		<?php endif; ?>
	</div>
	<div class="owl-carousel owl-theme">
	<?php  
	$args = array( 'post_type' => 'service',
			       'posts_per_page' => $numberof_services);
	$query = new WP_Query( $args );
	$number = 1;
	if($query->have_posts()):	
	while($query->have_posts()) : $query->the_post();
		  if(has_post_thumbnail(get_the_ID())):
              $attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
              $selfintro_crop_image = selfintro_resize($attachment_url, $width =473, $height =283,true); 
		  endif;
	 ?> 
     <div class="item">
	    	<a class="popup-with-form" href="#test-form<?php echo esc_attr($number); ?>">
	            <div class="self_service_section">
					<?php if(!empty($selfintro_crop_image)): ?>
	                <div class="self_service_img">
	                <span>
	                    <img src="<?php echo esc_url($selfintro_crop_image); ?>" alt="<?php the_title();?>">
	                </span> 
	                </div>  
                    <?php endif; ?>					
	                 <h4><?php the_title(); ?></h4>
	                    <p><?php echo selfintro_the_excerpt(150);?></p>  
	                </div>
                </a>
        </div>
		<?php 
		$number++;
		 endwhile;
        endif;	
		wp_reset_postdata();
		?>
	</div>
	<?php 
	$number =1;
	if($query->have_posts()):	
	while($query->have_posts()) : $query->the_post();
		  if(has_post_thumbnail(get_the_ID())):
              $attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
              $selfintro_crop_image = selfintro_resize($attachment_url, $width =100, $height =100,true); 
		  endif;
	?>
	<div id="test-form<?php echo esc_attr($number); ?>" class="self_service_detail mfp-hide">
	 <?php if(!empty($selfintro_crop_image)):?>
     	<div class="self_service_img">
        <span><img src="<?php echo esc_url($selfintro_crop_image); ?>" alt="<?php the_title(); ?>"></span>
        </div>
	<?php endif; ?>
	<h1><?php the_title(); ?></h1>
	<p><?php the_content(); ?></p>
	<?php if(!empty($selfintro_crop_image)):?>
        <div class="self_service_bg_img">
        	<img src="<?php echo esc_url($selfintro_crop_image); ?>" alt="<?php the_title(); ?>">
        </div>
	<?php endif; ?>	
     </div>
	 <?php 
	 $number++;
	    endwhile;
      endif;	
      wp_reset_postdata();
     ?>
</div>  