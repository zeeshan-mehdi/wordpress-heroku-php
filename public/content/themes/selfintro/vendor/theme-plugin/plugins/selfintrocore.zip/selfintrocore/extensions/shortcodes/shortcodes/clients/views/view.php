<?php
$our_clients = $logoimages = $selfintro_logoimages = $attachment_id ='';
if(!empty($atts['our_clients'])):
   $our_clients = $atts['our_clients'];
endif;
$clients_heading = '';
if(!empty($atts['clients_heading'])):
  $clients_heading = $atts['clients_heading'];
endif;
$clients_sub_heading = '';
if(!empty($atts['clients_sub_heading'])):
 $clients_sub_heading = $atts['clients_sub_heading'];
endif;
if(function_exists( 'fw_get_db_settings_option' )):	
   $selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?> 
<div class="prt_client_slider_wrapper">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<?php if(!empty($clients_heading)): ?>
						   <div class="prt_heading_wrapper">
							 <div class="prt_heading">
								<h1><?php echo esc_html($clients_heading); ?></h1>
								<?php 
								if($typedsettings == 'on'): 
									echo'<div class="typed_strings_clients">
										<p class="write_clients" data-strings-clients="'.esc_html($clients_sub_heading).'">'.esc_html($clients_sub_heading).'</p></div>';
								else:  
									echo '<p>'.esc_html($clients_sub_heading).'</p>';
								endif;
								?> 
							 </div>
						   </div>
						 <?php endif; ?>
					 </div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					   <div class="prt_client_slider">
						  <div class="owl-carousel owl-theme">
						   <?php 
						    if(!empty($our_clients)):
                               foreach($our_clients as $values):
                                 if(!empty($values['clients_icon']['url'])):
                                    $attachment_id = $values['clients_icon']['attachment_id'];
                                    $selfintro_logoimages = wp_get_attachment_url($attachment_id, 'full');
                                    $logoimages = selfintro_resize($selfintro_logoimages, 170, 103 , true); 
                                  endif;
								  $clients_url = '';
									if(!empty($values['clients_url'])):
									  $clients_url = $values['clients_url'];
									endif;
    						     if(!empty($logoimages)):
    								 echo '<div class="item">
    								        <a href="'.esc_url($clients_url).'"><img src="'.esc_url($logoimages).'" alt="'.esc_html__('Client','selfintro').'"></a>
    							  	     </div>';
    							 endif;
							    endforeach;
							  endif;
							?>
						  </div>
						</div>
					</div>
				</div>
		 </div>
 </div>