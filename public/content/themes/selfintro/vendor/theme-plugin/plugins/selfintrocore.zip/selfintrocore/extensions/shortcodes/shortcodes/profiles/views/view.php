<?php
$profiles_logo = '';
if(!empty($atts['profiles_slider'])):
    $profiles_logo = $atts['profiles_slider'];
endif;
?> 
<div class="container"> 
	<div class="row">
		<div class="prt_profile_info">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="prt_profile_slider">
					<div class="owl-carousel owl-theme">
					 <?php
					  if(!empty($profiles_logo)):
                       foreach($profiles_logo as $values):
                            if(!empty($values['title'])):
                                if(!empty($values['profile_image']['url'])):
                                $attachment_id = $values['profile_image']['attachment_id'];
                                   $selfintro_logoimage = wp_get_attachment_url($attachment_id, 'full');
                                   $logoimage = selfintro_resize($selfintro_logoimage, 70, 70 , true); 
                             endif; 
							 $profiles_url = '';
								if(!empty($values['profiles_url'])):
								  $profiles_url = $values['profiles_url'];
								endif;
                             ?>
                            <div class="item">
                              <a herf="<?php echo esc_url($profiles_url); ?>"><img src="<?php echo esc_url($logoimage); ?>"  alt="<?php echo esc_html($values['title']); ?>"/></a>
							  <h4><?php echo esc_html($values['title']); ?></h4>
							</div>  
							<?php 
							  endif;
							 endforeach;
							endif;
							?>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					 <div class="prt_heading_wrapper_2">
						<?php 
						$profiles_title = '';
                        if(!empty($atts['profiles_title'])):
                         $profiles_title = $atts['profiles_title'];
                        endif;
                        $profiles_sub_title = '';
                        if(!empty($atts['profiles_sub_title'])):
                         $profiles_sub_title = $atts['profiles_sub_title'];
                        endif;
                        $profiles_desc = '';
                        if(!empty($atts['profiles_desc'])):
                         $profiles_desc = $atts['profiles_desc'];
                        endif;
                        ?>  
						<div class="prt_heading">
							<h1><?php echo esc_html($profiles_title); ?></h1>
							<?php 
							if($typedsettings == 'on'): 
								echo'<div class="typed_strings_profiles">
									  <p class="write_profiles" data-strings-profiles="'.esc_html($profiles_sub_title).'">'.esc_html($profiles_sub_title).'</p>
								    </div>';
							else: 
								echo '<p>'.esc_html($profiles_sub_title).'</p>';
							endif;
							?>
						</div>
						</div>
						<div class="prt_profile_details">
							<p><?php printf($profiles_desc); ?></p>
						</div>
					</div>
				</div>
	   </div>
</div>