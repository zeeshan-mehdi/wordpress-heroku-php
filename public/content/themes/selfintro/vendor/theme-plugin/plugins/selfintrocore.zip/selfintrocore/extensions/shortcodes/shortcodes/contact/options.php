<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$options = array(
'contact_us_heading'  => array( 
	'label' => esc_html__('Contact Us Heading', 'selfintro'),
	'type' => 'text',
	'value' => '',
	'desc' => esc_html__('', 'selfintro'),
	), 	 
'contact_us_sub_heading'  => array( 
	'label' => esc_html__('Contact Us Sub Heading', 'selfintro'),
	'type' => 'text',
	'value' => '',
	'desc' => esc_html__('', 'selfintro'),
	), 	 
'form_heading'  => array( 
	'label' => esc_html__('Contact Us Form Heading', 'selfintro'),
	'type' => 'text',
	'value' => '',
	'desc' => esc_html__('', 'selfintro'),
	), 	 	
'form_shortcode'  => array( 
	'label' => esc_html__('Add Form Shortcode', 'selfintro'),
	'type' => 'text',
	'value' => '',
	'desc' => esc_html__('', 'selfintro'),
	),   
'googlemap_ifram'  => array( 
	'label' => esc_html__('Add Google Map Ifram', 'selfintro'),
	'type' => 'wp-editor',
	'value' => '',
	'desc' => esc_html__('', 'selfintro'),
	'media_buttons' => false,
	'wpautop' => false,
	),	     
'contactus_detail' =>array( 
	'type' => 'addable-popup',
	'value' => array(
			  array(
				 'contactus_address' => 'Contact Us Detail',
				 ), 
	         ),
	'label' => esc_html__('Add Contact Address', 'selfintro'),
		      'template' => '{{- objectives_title }}',
		      'popup-title' => null,
		      'size' => 'small', // small, medium, large
		      'limit' => 0, // limit the number of popup`s that can be added
	      	  'add-button-text' => esc_html__('Add', 'selfintro'), 
		      'sortable' => true, 
		      'popup-options' => array(
	'title' => array(
		          'label' => esc_html__('Title', 'selfintro'),
		           'type' => 'text', 
	               ),
	 'address_info'  => array( 
				   'label' => esc_html__('Address Information', 'selfintro'),
				   'type' => 'wp-editor',
			   	   'value' => '',
				   'desc' => esc_html__('', 'selfintro'),
				   'media_buttons' => false,
			       'wpautop' => false,
			      ),	   
	  'add_bg_image'  => array( 
			        'label' => esc_html__('Background Image', 'selfintro'),
			        'desc' => esc_html__('Upload Profile images Here.', 'selfintro'),
			         'type' => 'upload', 
			       ),   
			 ), 
	     ),	
     'map_address' => array(
		           'label' => esc_html__('Google Map Address', 'selfintro'),
		           'type' => 'text',
	              ),
	'longitude' => array(
		           'label' => esc_html__('Longitude', 'selfintro'),
		           'type' => 'text',
	              ), 
    'latitude' => array(
		           'label' => esc_html__('Latitude', 'selfintro'),
		           'type' => 'text',
	               ),
	'map_zoom' => array(
			    'type'  => 'text',
				'label' => esc_html__('Enter Google Map Zoom', 'selfintro'),
				),
	'geometry' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Geometry Color Set', 'selfintro'),
            'desc'  => __('Map Geometry Color', 'selfintro'),
           ),
   'labelstextstroke' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Labelstextstroke Color Set', 'selfintro'),
            'desc'  => __('Map Labelstextstroke Color', 'selfintro'),
           ),
	'labelstextfill' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Labelstextfill Color Set', 'selfintro'),
            'desc'  => __('Map Labelstextfill Color', 'selfintro'),
           ),
	'poi_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Poi Color Set', 'selfintro'),
            'desc'  => __('Map Labelstextfill Color', 'selfintro'),
           ),
	'locality_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Locality Color Set', 'selfintro'),
            'desc'  => __('Map Locality Color', 'selfintro'),
           ),
	'poi_park_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Poi Park Color Set', 'selfintro'),
            'desc'  => __('Map Poi Park Color', 'selfintro'),
           ),
	'road_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Road Color Set', 'selfintro'),
            'desc'  => __('Map Road Color', 'selfintro'),
           ),
	'text_fill_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Text Fill Color Set', 'selfintro'),
            'desc'  => __('Map Text Fill Color', 'selfintro'),
           ),
	'road_highway_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Road Highway Color Set', 'selfintro'),
            'desc'  => __('Map Road Highway Color', 'selfintro'),
           ),
	'road_stroke_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Road Stroke Color Set', 'selfintro'),
            'desc'  => __('Map Road Stroke Color', 'selfintro'),
           ),
	'road_text_fill_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Road Text Fill Color Set', 'selfintro'),
            'desc'  => __('Map Road Text Fill Color', 'selfintro'),
           ), 
	'transit_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Transit Color Set', 'selfintro'),
            'desc'  => __('Map Transit Color', 'selfintro'),
           ),
	'transitstation_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Transit Station Color Set', 'selfintro'),
            'desc'  => __('Map Transit Station Color', 'selfintro'),
           ),
	'water_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Water Color Set', 'selfintro'),
            'desc'  => __('Map Water Color', 'selfintro'),
           ),
	'water_text_fill_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Water Text Fill Color Set', 'selfintro'),
            'desc'  => __('Map Water Color', 'selfintro'),
           ),
	'water_text_stroke_color' => array(
            'type'  => 'color-picker',
            'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
            'label' => __('Map Water Text Fill Color Set', 'selfintro'),
            'desc'  => __('Map Water Color', 'selfintro'),
           ),		 
 ); 