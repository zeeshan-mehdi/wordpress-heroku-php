<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$options = array(
'button_text'  => array( 
	'about_label' => esc_html__('Button Title', 'selfintro'),
	'type' => 'text',
	'value' => '',
	'desc' => esc_html__('', 'selfintro'),
	), 
'resume_download'  => array(
           'type'  => 'upload',
           'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
           'label' => __('Resume File Upload', 'selfintro'),
           'desc'  => __('Resume File Upload', 'selfintro'),
           'help'  => __('Help tip', 'selfintro'),
           'images_only' => false,
          ),
'resume_download_url'  => array( 
		'about_label' => esc_html__('Resume Download File Link', 'selfintro'),
		'type' => 'text',
		'value' => '',
		 'desc' => esc_html__('', 'selfintro'),
		 ),
);