<?php 
if(function_exists( 'fw_get_db_settings_option' )):	
	$selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?> 
<div class="prt_portfolio_wrapper prt_toppadder115">
		<div class="prt_close_wrapper">
		  <i class="fa fa-chevron-right prt_close"></i>
		</div>
		<div class="container"> 
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="prt_heading_wrapper">
					    <?php
					    $portfolio_heading = '';
                        if(!empty($selfintro_data['portfolio_heading'])):
                          $portfolio_heading = $selfintro_data['portfolio_heading'];
                        endif;
                        $portfolio_sub_heading = '';
                        if(!empty($selfintro_data['portfolio_sub_heading'])):
                           $portfolio_sub_heading = $selfintro_data['portfolio_sub_heading'];
                        endif;
                        $portfolio_show_number = '';
                        if(!empty($selfintro_data['portfolio_show_number'])):
                           $portfolio_show_number = $selfintro_data['portfolio_show_number'];
                        endif;
                        $portfolio_load_number = '';
                        if(!empty($selfintro_data['portfolio_load_number'])):
                           $portfolio_load_number = $selfintro_data['portfolio_load_number'];
                        endif;
					    if(!empty($portfolio_heading)):
						echo '<div class="prt_heading">
							  <h1>'.esc_html($portfolio_heading).'</h1>';
							    if($typedsettings == 'on'): 
							        echo'<div class="typed_strings_portfolio">
								        <p class="write_portfolio" data-strings-portfolio="'.esc_html($portfolio_sub_heading).'">'.esc_html($portfolio_sub_heading).'</p></div>';
						        else:  
						             echo '<p>'.esc_html($portfolio_sub_heading).'</p>';
					            endif;
						echo '</div>';
						endif;
						?>  
				    </div>
				</div>
		<div id="ajax_portplio_shortcode">
		<div class="prt_portfolio_box popup-gallery">
		<?php
		$number = 1;
		$column = '3';  
		$args = array('post_type' => 'portfolio', 
					  'posts_per_page'=>$portfolio_show_number); 
		$selfintro_query = new WP_Query($args); 
		if($selfintro_query->have_posts()):
		  while($selfintro_query->have_posts()):
				$selfintro_query->the_post();
		          
		$selfintro_data = ''; 
		if(function_exists( 'fw_get_db_post_option' )):	
			 $selfintro_data = fw_get_db_post_option(get_the_ID());
		endif;    
		$youtub_video_url = '';
		if(!empty($selfintro_data['video_url'])):	
			 $youtub_video_url = $selfintro_data['video_url'];
		endif; 
		
		$image_sub_title = '';
		if(!empty($selfintro_data['image_sub_title'])):	
			  $image_sub_title = $selfintro_data['image_sub_title'];
		endif; 
		$video_title = '';
		if(!empty($selfintro_data['video_title'])):	
				 $video_title = $selfintro_data['video_title'];
		 endif; 
		$video_sub_title = '';
		if(!empty($selfintro_data['video_sub_title'])):	
			 $video_sub_title = $selfintro_data['video_sub_title'];
		endif; 
		$portfolio_style = '';
		if(!empty($selfintro_data['portfolio_style'])):	
			 $portfolio_style = $selfintro_data['portfolio_style'];
		endif;  
		switch($portfolio_style) {
			 case 'style1':
			  echo '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">';
			  if(has_post_thumbnail(get_the_ID())):
				$attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
				$image_resize_url = selfintro_resize($attachment_url,360,360,true);
				$video_image_url = '';
			  if(!empty($selfintro_data['video_image']['attachment_id'])):	
					   $attachment_id = $selfintro_data['video_image']['attachment_id'];
					   $video_image_corup = wp_get_attachment_url($attachment_id, 'full');
					   $video_image_url = selfintro_resize($video_image_corup,360,360,true);
				endif; 
			  endif;  
			 break;
			  case 'style2':
				echo '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">';
				$video_image_url = '';
			if(!empty($selfintro_data['video_image']['attachment_id'])):	
				   $attachment_id = $selfintro_data['video_image']['attachment_id'];
				   $video_image_corup = wp_get_attachment_url($attachment_id, 'full');
				   $video_image_url = selfintro_resize($video_image_corup,760,360,true);
			endif; 
			if(has_post_thumbnail(get_the_ID())):
					$attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
					$image_resize_url = selfintro_resize($attachment_url,760,360,true);
				  endif;  
			 break;
			 default: 
			 echo '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">';
			  if(has_post_thumbnail(get_the_ID())):
				$attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
				$image_resize_url = selfintro_resize($attachment_url,360,360,true);
			  endif;  
			  $video_image_url = '';
		if(!empty($selfintro_data['video_image']['attachment_id'])):	
			   $attachment_id = $selfintro_data['video_image']['attachment_id'];
			   $video_image_corup = wp_get_attachment_url($attachment_id, 'full');
			   $video_image_url = selfintro_resize($video_image_corup,360,360,true);
		endif; 
		}
		?> 
		<a class="imageopen" href="<?php echo esc_url($attachment_url); ?>" title="<?php esc_html_e('Portfolio','selfintro') ?>">
			<div class="prt_portfolio_img">
			  <?php if(!empty($image_resize_url)): ?>
				<img src="<?php echo esc_url($image_resize_url); ?>" alt="<?php esc_html_e('Portfolio','selfintro') ?>">
				 <?php endif; ?>
			  <div class="prt_portfolio_text">
				 <h4><?php the_title(); ?></h4>
				 <p><?php echo esc_html($image_sub_title)?></p>
			</div>
		  </div>
		</a>
		<?php if(!empty($youtub_video_url)): ?>
		<a class="popup-youtube" href="<?php echo esc_url($youtub_video_url);?>" title="<?php echo esc_html($video_title); ?>">
		<?php if(!empty($video_image_url)): ?>
			<div class="prt_portfolio_img">
			  <img src="<?php echo esc_url($video_image_url); ?>" alt="<?php esc_html_e('Portfolio','selfintro'); ?>">
			  <div class="prt_portfolio_text">
				<?php if(!empty($video_title)): ?>
					<h4><?php echo esc_html($video_title); ?></h4>
				<?php
			endif;
			if(!empty($video_sub_title)): ?>
			<p><?php echo esc_html($video_sub_title); ?></p>
			<?php endif; ?>
		  </div>
		</div>
		<?php endif; ?>
		</a> 
		<?php endif; ?>
		</div> 
		<?php  
		$number++;
		endwhile;	
		endif; 
		wp_reset_postdata();				
		?> 
		</div>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center ajxload">
			<button class="prt_btn">
			<?php esc_html_e('load more','selfintro'); ?></button>
			<div class="prt_loader"><div class="loader"></div></div>
			<input type="hidden" value="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"  id="ajaxurl">
			<input type="hidden" class="ajx_auto_incriment"  value="1" />
			<input type="hidden" class="ajx_prot_number"  value="<?php echo esc_attr($portfolio_show_number); ?>" /><input type="hidden" class="ajx_prot_showmore"  value="<?php echo esc_attr($portfolio_load_number); ?>" />
		</div> 
	  </div>  
	</div>
	<?php selfintro_footer_copyright(); ?>	
 </div> 