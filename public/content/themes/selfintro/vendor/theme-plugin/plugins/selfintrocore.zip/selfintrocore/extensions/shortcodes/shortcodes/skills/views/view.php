<?php if(!defined('FW')) {
	die( 'Forbidden' );
} 
$skills_heading = '';
if(!empty($atts['skills_heading'])):
    $skills_heading = $atts['skills_heading'];
endif;
$skills_sub_heading = '';
if(!empty($atts['skills_sub_heading'])):
    $skills_sub_heading = $atts['skills_sub_heading'];
endif;
$our_skills = '';
$idv = 1;
if(!empty($atts['our_skills'])):
  $our_skills = $atts['our_skills'];
endif;
if(function_exists( 'fw_get_db_settings_option' )):	
   $selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?>  
<div class="prt_skills_wrapper">
	<div class="container">
		 <div class="row">
			 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				 <div class="prt_heading_wrapper">
				   <?php
					if(!empty($skills_heading)):
						echo '<div class="prt_heading">
    						    <h1>'.esc_html($skills_heading).'</h1>';
								if($typedsettings == 'on'): 
								    echo'<div class="typed_strings_skills">
									      <p class="write_skills" data-strings-skills="'.esc_html($skills_sub_heading).'">'.esc_html($skills_sub_heading).'</p>
								        </div>';
								else: 
									echo '<p>'.esc_html($skills_sub_heading).'</p>';
								endif;
    					echo '</div>';
					 endif;
					?>   
					 </div> 
					</div>
					<div id="canvas">
					<?php
				    if(!empty($our_skills)):
                    foreach($our_skills as $values):
                    $percent = '';
                    if(!empty($values['skills_number'])):
                       $percent  = $values['skills_number'];
                    endif;
                    $bgFill = '';
                    if(!empty($values['skills_color_bgFill'])):
                       $bgFill  = $values['skills_color_bgFill'];
                    endif;
                    $frFill = '';
                    if(!empty($values['skills_color_frFill'])):
                       $frFill  = $values['skills_color_frFill'];
                    endif;
                    $textcolor = '';
                    if(!empty($values['skills_textcolor'])):
                       $textcolor  = $values['skills_textcolor'];
                    endif;
                    $skill_bgimage = '';
                    if(!empty($values['skills_icon']['url'])):
                       $skill_bgimage  = $values['skills_icon']['url'];
                    endif;
            	   ?>
            	   <script>
                	jQuery(document).ready(function ($) {
                        "use strict";
                	   jQuery('#circle-<?php echo esc_js($idv); ?>').circleDiagram();
                	});
            		</script>
            		<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 text-center">
                      <div id="circle-<?php echo esc_html($idv); ?>"
            		     class="diagram" style="background-image:url(<?php echo esc_html($skill_bgimage); ?>); background-size:cover; background-repeat:no-repeat; background-position:center;"
            		     data-circle-diagram='{
            			"percent": "<?php echo esc_html($percent);?>%",
            			"size": "200",
            			"borderWidth": "8",
            			"bgFill": "<?php echo esc_html($bgFill); ?>",
            			"frFill": "<?php echo esc_html($frFill); ?>",
            			"textSize": "30",
            			"textColor": "<?php echo esc_html($textcolor); ?>"
            			}'>
            	       </div>
            	      <?php 
            	      if(!empty($values['skills_title'])):
						 echo '<h5>'.esc_html($values['skills_title']).'</h5>';
					  endif;
            	     ?>
            	    </div> 
                    <?php 
                      $idv++;
					  endforeach;
					 endif;
					?> 
					</div>
			 </div>
		</div>
 </div> 