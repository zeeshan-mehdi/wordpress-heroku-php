<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} 
$heading = '';
if(!empty($atts['heading'])):
	$heading = $atts['heading'];
endif;
$map_address = '';
if(!empty($atts['map_address'])):
	$heading = $atts['map_address'];
endif;
$longitude = -73.945;
if(!empty($atts['longitude'])):
	$longitude = $atts['longitude'];
endif;
$latitude =40.674;
if(!empty($atts['latitude'])):
	$latitude = $atts['latitude'];
endif;
$map_zoom = 12;
if(!empty($atts['map_zoom'])):
	$latitude = $atts['map_zoom'];
endif;
$geometry = '';
if(!empty($atts['geometry'])):
	$geometry = $atts['geometry'];
endif;
$labelstextstroke = '';
if(!empty($atts['labelstextstroke'])):
	$labelstextstroke = $atts['labelstextstroke'];
endif;
$labelstextfill = '';
if(!empty($atts['labelstextfill'])):
	$labelstextfill = $atts['labelstextfill'];
endif;
$labelstextstroke = '';
if(!empty($atts['labelstextstroke'])):
	$labelstextstroke = $atts['labelstextstroke'];
endif;
$poi_color = '';
if(!empty($atts['poi_color'])):
	$poi_color = $atts['poi_color'];
endif;
$locality_color = '';
if(!empty($atts['locality_color'])):
	$locality_color = $atts['locality_color'];
endif;
$poi_park_color = '';
if(!empty($atts['poi_park_color'])):
	$poi_park_color = $atts['poi_park_color'];
endif;
$road_color = '';
if(!empty($atts['road_color'])):
	$road_color = $atts['road_color'];
endif;
$text_fill_color = '';
if(!empty($atts['text_fill_color'])):
	$text_fill_color = $atts['text_fill_color'];
endif;
$road_highway_color = '';
if(!empty($atts['road_highway_color'])):
	$road_highway_color = $atts['road_highway_color'];
endif;
$road_stroke_color = '';
if(!empty($atts['road_stroke_color'])):
	$road_highway_color = $atts['road_stroke_color'];
endif;
$road_text_fill_color = '';
if(!empty($atts['road_text_fill_color'])):
	$road_text_fill_color = $atts['road_text_fill_color'];
endif;
$transit_color = '';
if(!empty($atts['transit_color'])):
	$transit_color = $atts['transit_color'];
endif;
$transitstation_color = '';
if(!empty($atts['transitstation_color'])):
	$transitstation_color = $atts['transitstation_color'];
endif;
$water_color = '';
if(!empty($atts['water_color'])):
	$water_color = $atts['water_color'];
endif;
$water_text_fill_color = '';
if(!empty($atts['water_text_fill_color'])):
	$water_text_fill_color = $atts['water_text_fill_color'];
endif;
$water_text_stroke_color = '';
if(!empty($atts['water_text_stroke_color'])):
	$water_text_stroke_color = $atts['water_text_stroke_color'];
endif;
?>
<div class="sl_color_map">
 <div id="map"></div> 
</div>
<script>
// Styles a map in night mode.
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: <?php echo esc_js($latitude); ?>, lng: <?php echo esc_js($longitude); ?>},
          zoom: <?php echo esc_js($map_zoom); ?>, 
          styles: [
            {elementType: 'geometry', stylers: [{color: '<?php echo esc_js($geometry); ?>'}]},
            {elementType: 'labels.text.stroke', stylers: [{color: '<?php echo esc_js($labelstextstroke); ?>'}]},
            {elementType: 'labels.text.fill', stylers: [{color: '<?php echo esc_js($labelstextfill); ?>'}]},
            {
              featureType: 'administrative.locality',
              elementType: 'labels.text.fill',
              stylers: [{color: '<?php echo esc_js($locality_color); ?>'}]
            },
            {
              featureType: 'poi',
              elementType: 'labels.text.fill',
              stylers: [{color: '<?php echo esc_js($poi_color); ?>'}]
            },
            {
              featureType: 'poi.park',
              elementType: 'geometry',
              stylers: [{color: '<?php echo esc_js($poi_park_color); ?>'}]
            },
            {
              featureType: 'poi.park',
              elementType: 'labels.text.fill',
              stylers: [{color: '#6b9a76'}]
            },
            {
              featureType: 'road',
              elementType: 'geometry',
              stylers: [{color: '<?php echo esc_js($road_color); ?>'}]
            },
            {
              featureType: 'road',
              elementType: 'geometry.stroke',
              stylers: [{color: '<?php echo esc_js($road_stroke_color); ?>'}]
            },
            {
              featureType: 'road',
              elementType: 'labels.text.fill',
              stylers: [{color: '<?php echo esc_js($text_fill_color); ?>'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'geometry',
              stylers: [{color: '<?php echo esc_js($road_highway_color); ?>'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'geometry.stroke',
              stylers: [{color: '<?php echo esc_js($road_stroke_color); ?>'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'labels.text.fill',
              stylers: [{color: '<?php echo esc_js($road_text_fill_color); ?>'}]
            },
            {
              featureType: 'transit',
              elementType: 'geometry',
              stylers: [{color: '<?php echo esc_js($transit_color); ?>'}]
            },
            {
              featureType: 'transit.station',
              elementType: 'labels.text.fill',
              stylers: [{color: '<?php echo esc_js($transitstation_color ); ?>'}]
            },
            {
              featureType: 'water',
              elementType: 'geometry',
              stylers: [{color: '<?php echo esc_js($water_color); ?>'}]
            },
            {
              featureType: 'water',
              elementType: 'labels.text.fill',
              stylers: [{color: '<?php echo esc_js($water_text_fill_color); ?>'}]
            },
            {
              featureType: 'water',
              elementType: 'labels.text.stroke',
              stylers: [{color: '<?php echo esc_js($water_text_stroke_color); ?>'}]
            }
          ] 
          
        });
</script> 