<?php
if(function_exists( 'fw_get_db_settings_option' )):	
	$selfintro_data = fw_get_db_settings_option();  
endif; 
$logo_image ='';
if(!empty($selfintro_data['logo_image']['url'])):
   $logo_image = $selfintro_data['logo_image']['url'];
else:
   $logo_image = get_template_directory_uri().'/assets/images/logo.png';
endif;
if(!empty($selfintro_data['banner_image']['url'])):
  $banner_image = $selfintro_data['banner_image']['url'];
endif;
$text_image = '';
if(!empty($selfintro_data['text_image']['url'])):
  $text_image = $selfintro_data['text_image']['url'];
endif;
$logo_svgcode = '';
if(!empty($selfintro_data['logo_svgcode'])):
    $logo_svgcode =$selfintro_data['logo_svgcode'];
endif;
$loader_image = '';
if(!empty($selfintro_data['loader_image']['url'])):
  $loader_image = $selfintro_data['loader_image']['url'];
else:
  $loader_image = get_template_directory_uri().'/assets/images/loader.gif';
endif;
$loader_image = '';
if(!empty($selfintro_data['loader_switch'])):
  $loader_switch = $selfintro_data['loader_switch'];
endif;
$selfintro_color = '';
if(!empty($selfintro_data['selfintro_color'])):
   $selfintro_color = $selfintro_data['selfintro_color'];
endif;
$us_text = '';
if(!empty($selfintro_data['us_text'])):
  $us_text = $selfintro_data['us_text'];
endif;
$banner_image_url = '';
if(!empty($banner_image)):
   $banner_image_url = 'background-image:url(' .$banner_image. ');';
endif;
$text_image_url = '';
if(!empty($text_image)):
   $text_image_url = 'background-image:url('.$text_image.');';
endif;  
$shop_page_url = '';
if(!empty($selfintro_data['shop_pageurl'])):
    $shop_page_url =$selfintro_data['shop_pageurl'];
endif;
$shop_icon = '';
if(!empty($selfintro_data['shop_icon'])):
    $shop_icon =$selfintro_data['shop_icon'];
endif;
$video_url = '';
if(!empty($selfintro_data['video_url'])):
    $video_url =$selfintro_data['video_url'];
endif;
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
    $typedsettings =$selfintro_data['banner_switch_typed'];
endif; 
$videosettings = '';
if(!empty($selfintro_data['banner_video_switch'])):
    $videosettings =$selfintro_data['banner_video_switch'];
endif; 
$whitebanere = '';
if($selfintro_color ==2):
 $whitebanere = 'home_white';
endif;
if($videosettings == 'on'):
?>
<div class="prt_home_wrapper prt_videohome <?php echo esc_html($whitebanere);?>">
		<div class="prt_logo_wrapper">
		    <?php 
			if(empty($logo_svgcode)):
			    if(!empty($logo_image)): ?>
				  <a href="<?php echo esc_url(home_url('/')); ?>">
                  <img src="<?php echo esc_url($logo_image); ?>" alt=""></a>
			<?php
             endif;				
			else:
				echo '<a href="'.esc_url(home_url('/')).'">';
					   printf($logo_svgcode);
				echo '</a>';
			endif;
			?>
		</div>
		<div class="prt_menu_wrapper"> 
		    <?php 
		    $loader_image = '';
            if(!empty($selfintro_data['custom_menu'])):
                $custom_menu = $selfintro_data['custom_menu'];
            endif;
            if(!empty($custom_menu)):
                foreach($custom_menu as $values):
                  if(!empty($values['class_style']) && !empty($values['menu_id']) && !empty($values['title'])):
                  echo '<a href="#'.$values['menu_id'].'" class="'.$values['class_style'].'">'. $values['title'].'</a>';
                  endif;
    		    endforeach;
		    endif;
			?>
		</div>
		<?php 
		if(!empty($video_url)):
		?>
		<video autoplay muted loop id="myVideo">
		    <source src="<?php echo esc_url($video_url); ?>" type="video/mp4">
			<?php esc_html_e('Your browser does not support HTML5 video.',''); ?>
	    </video>
	    <?php  
		 endif; 
		?>
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h1 style=<?php printf($text_image_url); ?>><?php printf($us_text); ?></h1>
				</div>
			</div>
		</div> 
   </div>
<?php
else:
?> 
<div class="prt_home_wrapper <?php echo esc_html($whitebanere);?>" style=<?php printf($banner_image_url); ?>>
        <div class="prt_logo_wrapper">
		    <?php 
			if(empty($logo_svgcode)):
			    if(!empty($logo_image)): ?>
				  <a href="<?php echo esc_url(home_url('/')); ?>">
                  <img src="<?php echo esc_url($logo_image); ?>" alt=""></a>
			<?php
             endif;				
			else:
				echo '<a href="'.esc_url(home_url('/')).'">';
					   printf($logo_svgcode);
				echo '</a>';
			endif;
			?>
		</div>
		<div class="prt_menu_wrapper"> 
		    <?php 
		    $loader_image = '';
            if(!empty($selfintro_data['custom_menu'])):
                $custom_menu = $selfintro_data['custom_menu'];
            endif;
            if(!empty($custom_menu)):
                foreach($custom_menu as $values):
                  if(!empty($values['class_style']) && !empty($values['menu_id']) && !empty($values['title'])):
                  echo '<a href="#'.$values['menu_id'].'" class="'.$values['class_style'].'">'. $values['title'].'</a>';
                  endif;
    		    endforeach;
		    endif;
			?>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-7 col-sm-10 col-xs-12 col-lg-offset-6 col-md-offset-5 col-sm-offset-2 col-xs-offset-0">
				<?php 
				if($typedsettings == 'on'): ?>
				    <div class="typed_strings">
				     <?php if(!empty($us_text)): ?>
					    <h1 class="write"  data-strings="<?php printf($us_text); ?>" style=<?php printf($text_image_url); ?>>
					       <?php printf($us_text); ?>
						</h1> 
					<?php endif; ?>
					</div> 
				<?php  
				  else:
				    if(!empty($us_text)): ?>
					  <h1 style=<?php printf($text_image_url); ?>>
					      <?php printf($us_text); ?></h1>
				<?php endif;
                  endif;
				?>
				</div>
			</div>
		</div>
		<?php 
		if(!empty($shop_page_url)): ?>
		<div class="self_shop_cart">
			<a href="<?php echo esc_url($shop_page_url); ?>" target="_blank">
			<?php if(!empty($shop_icon)):
			    printf($shop_icon);
			else:
			    echo '<i class="fa fa-opencart"></i>';
			endif;
			?>
			</a>
		</div>
		<?php endif; ?>
	</div> 
<?php  endif; ?>	