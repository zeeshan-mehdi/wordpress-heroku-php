<?php if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;
$cfg = array();
$cfg['page_builder'] = array(
	'title'       => esc_html__('Product', 'selfintro'),
	'description' => esc_html__('Product Section', 'selfintro'),
	'tab'         => esc_html__('Selfintro Shortcode', 'selfintro'),
    'icon'  =>'fa fa-pencil-square-o',  
); 