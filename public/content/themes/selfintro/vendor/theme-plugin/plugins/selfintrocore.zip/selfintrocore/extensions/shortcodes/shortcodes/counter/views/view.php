<?php if(!defined('FW')) {
	die( 'Forbidden' );
}
$our_award = $logoimages = $selfintro_logoimages = $attachment_id= '';
if(!empty($atts['our_award'])):
    $our_award = $atts['our_award'];
endif;
$award_bg_image = '';
if(!empty($atts['award_bg_image']['url'])):
      $award_bg_image = $atts['award_bg_image']['url'];
endif;
$bg_image_url = '';
if(!empty($award_bg_image)):
     $bg_image_url = 'background-image:url(' .$award_bg_image. ');';
endif;
?> 
<div class="prt_couter_wrapper prt_toppadder80 prt_bottompadder50" style="<?php printf($bg_image_url); ?>">
		<div class="container">
			<div class="row">
				<?php 
				if(!empty($our_award)):
                   foreach($our_award as $values):
                      if(!empty($values['award_icon']['url'])):
                        $attachment_id = $values['award_icon']['attachment_id'];
                        $selfintro_logoimages = wp_get_attachment_url($attachment_id, 'full');
                        $logoimages = selfintro_resize($selfintro_logoimages, 100, 100 , true); 
                        endif;
                        $award_number = '';
                        if(!empty($values['award_number'])):
                          $award_number = $values['award_number'];
                        endif;
                        $award_title = '';
                        if(!empty($values['award_title'])):
                          $award_title = $values['award_title'];
                        endif;
    				    echo '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
    						 <div class="prt_counter_box">';
    						  if(!empty($logoimages)):
    							 echo '<img src="'.esc_url($logoimages).'" alt="'.esc_html__('Clients','selfintro').'">';
    						  endif;
    						  if(!empty($award_number)):
    							 echo'<h3 class="timer" data-from="0" data-to="'.esc_html($award_number).'" data-speed="5000"></h3>';
    						 endif;	 
    						 if(!empty($award_title)):
    							 echo '<p>'.esc_html($award_title).'</p>';
    						 endif;
    				   echo '</div>
    					</div>';
				 endforeach;
				endif;
				?>
			 </div>
		</div>
 </div> 