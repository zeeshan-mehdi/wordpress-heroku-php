<?php
/**
 *coustem post types
 */
add_action('init', 'selfintro_coustemposttype');
function selfintro_coustemposttype() {
/**
 * Selfintro Education Custem Post 
 */	
register_post_type('education', array(
        'labels' => array (
            'name' => esc_html__( 'Education', 'selfintro'),
            'singular_name' => esc_html__( 'Education', 'selfintro'),
            'add_new' =>esc_html__( 'Add New', 'selfintro' ),
            'add_new_item' =>esc_html__( 'Add New Education', 'selfintro'),
            'edit_item' =>esc_html__( 'Edit Education', 'selfintro'),
            'new_item' =>esc_html__( 'New Education', 'selfintro'),
            'all_items' =>esc_html__( 'All Education', 'selfintro'),
            'view_item' =>esc_html__( 'View Education', 'selfintro'),
            'search_items' =>esc_html__( 'Search Education', 'selfintro'),
            'not_found' =>esc_html__('No Education found', 'selfintro' ),
            'not_found_in_trash' =>esc_html__('No Education found in Trash', 'selfintro'),
           'parent_item_colon' => '',
           'menu_name' =>esc_html__('Education', 'selfintro')
            ),
        'public' => true,
		'menu_icon' => 'dashicons-welcome-learn-more',
        'has_archive' => false,
        'rewrite' => true,
        'capability_type' => 'page',
        'supports' => array ( 'title','editor', 'author','thumbnail') ) );  
        register_taxonomy ('education-category', 
		  array ('education'), 
		       array(
			    'hierarchical' => true,
			    'label' =>esc_html__('Education Categories', 'selfintro'),
			    'singular_label' =>esc_html__('Education Categories', 'selfintro'),
			    'rewrite' => true)
		         );
	 
/**
 * Selfintro Experience Custem Post 
 */	
register_post_type('experience', array(
        'labels' => array (
            'name' => esc_html__( 'Experience', 'selfintro'),
            'singular_name' => esc_html__( 'Experience', 'selfintro'),
            'add_new' =>esc_html__( 'Add New', 'selfintro' ),
            'add_new_item' =>esc_html__( 'Add New Experience', 'selfintro'),
            'edit_item' =>esc_html__( 'Edit Experience', 'selfintro'),
            'new_item' =>esc_html__( 'New Experience', 'selfintro'),
            'all_items' =>esc_html__( 'All Experience', 'selfintro'),
            'view_item' =>esc_html__( 'View Experience', 'selfintro'),
            'search_items' =>esc_html__( 'Search Experience', 'selfintro'),
            'not_found' =>esc_html__('No Experience found', 'selfintro' ),
            'not_found_in_trash' =>esc_html__('No Experience found in Trash', 'selfintro'),
           'parent_item_colon' => '',
           'menu_name' =>esc_html__('Experience', 'selfintro')
            ),
        'public' => true,
		'menu_icon' => 'dashicons-awards', 
        'has_archive' => false,
        'rewrite' => true,
        'capability_type' => 'page',
        'supports' => array ( 'title','editor', 'author','thumbnail') ) );  
        register_taxonomy ('experience-category', 
		  array ('experience'), 
		       array(
			    'hierarchical' => true,
			    'label' =>esc_html__('Experience Categories', 'selfintro'),
			    'singular_label' =>esc_html__('Experience Categories', 'selfintro'),
			    'rewrite' => true)
		         );
/**
 * Selfintro Portfolio Custem Post 
 */	
register_post_type('portfolio', array(
        'labels' => array (
        'name' => esc_html__( 'Portfolio', 'selfintro'),
        'singular_name' => esc_html__( 'Portfolio', 'selfintro'),
        'add_new' =>esc_html__( 'Add New', 'selfintro' ),
        'add_new_item' =>esc_html__( 'Add New Portfolio', 'selfintro'),
        'edit_item' =>esc_html__( 'Edit Portfolio', 'selfintro'),
        'new_item' =>esc_html__( 'New Portfolio', 'selfintro'),
        'all_items' =>esc_html__( 'All Portfolio', 'selfintro'),
        'view_item' =>esc_html__( 'View Portfolio', 'selfintro'),
        'search_items' =>esc_html__( 'Search Portfolio', 'selfintro'),
        'not_found' =>esc_html__('No Portfolio found', 'selfintro' ),
        'not_found_in_trash' =>esc_html__('No Portfolio found in Trash', 'selfintro'),
        'parent_item_colon' => '',
        'menu_name' =>esc_html__('Portfolio', 'selfintro')
        ), 
        'public' => true,
		'menu_icon' => 'dashicons-images-alt', 
        'has_archive' => false, 
        'rewrite' => true,
        'capability_type' => 'page',
        'supports' => array ( 'title','editor', 'author','thumbnail') ) );  
        register_taxonomy ('portfolio-category', 
		  array ('portfolio'), 
		       array(
			    'hierarchical' => true,
			    'label' =>esc_html__('Portfolio Categories', 'selfintro'),
			    'singular_label' =>esc_html__('Portfolio Categories', 'selfintro'),
			    'rewrite' => true)
		         );
/**
 * Selfintro Portfolio Custem Post 
 */	
register_post_type('service', array(
        'labels' => array (
        'name' => esc_html__( 'Service', 'selfintro'),
        'singular_name' => esc_html__( 'Service', 'selfintro'),
        'add_new' =>esc_html__( 'Add New', 'selfintro' ),
        'add_new_item' =>esc_html__( 'Add New Service', 'selfintro'),
        'edit_item' =>esc_html__( 'Edit Service', 'selfintro'),
        'new_item' =>esc_html__( 'New Service', 'selfintro'),
        'all_items' =>esc_html__( 'All Service', 'selfintro'),
        'view_item' =>esc_html__( 'View Service', 'selfintro'),
        'search_items' =>esc_html__( 'Search Service', 'selfintro'),
        'not_found' =>esc_html__('No Service found', 'selfintro' ),
        'not_found_in_trash' =>esc_html__('No Service found in Trash', 'selfintro'),
        'parent_item_colon' => '',
        'menu_name' =>esc_html__('Service', 'selfintro')
        ), 
        'public' => true,
		'menu_icon' => 'dashicons-images-alt', 
        'has_archive' => false, 
        'rewrite' => true,
        'capability_type' => 'page',
        'supports' => array ( 'title','editor', 'author','thumbnail') ) );  
        register_taxonomy ('service-category', 
		   array ('service'), 
		       array(
			    'hierarchical' => true,
			    'label' =>esc_html__('Service Categories', 'selfintro'),
			    'singular_label' =>esc_html__('Service Categories', 'selfintro'),
			    'rewrite' => true)
		         );   
		         		 		 
}  