<?php if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;
$cfg = array();
$cfg['page_builder'] = array(
	'title'       => esc_html__('Contact Us', 'selfintro'),
	'description' => esc_html__('Contact Us Section', 'selfintro'),
	'tab'         => esc_html__('Selfintro Shortcode', 'selfintro'),
    'icon'  =>'fa fa-pencil-square-o',  
);  