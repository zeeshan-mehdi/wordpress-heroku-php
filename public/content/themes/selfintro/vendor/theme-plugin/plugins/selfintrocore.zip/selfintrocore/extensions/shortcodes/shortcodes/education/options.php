<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} 
$options = array(
      'education_heading'  => array( 
			'label' => esc_html__('Education Heading', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			), 	 
	  'education_sub_heading'  => array( 
			'label' => esc_html__('Education Sub Heading', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			), 	  		
	  'education_number'  => array( 
			'label' => esc_html__('Show Number Of Education', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			), 	 
);  