<?php 
if(function_exists( 'fw_get_db_settings_option' )):	
	$selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif; 
?>  
<div class="prt_services_wrapper prt_toppadder115">
    		<div class="prt_close_wrapper">
    			<i class="fa fa-chevron-up prt_close"></i>
    		</div>
		<div class="prt_services_slider_wrapper prt_bottompadder115">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					    <?php 
					    $services_heading = '';
                        if(!empty($selfintro_data['services_heading'])):
                           $services_heading = $selfintro_data['services_heading'];
                        endif;
                        $services_sub_heading = '';
                        if(!empty($selfintro_data['services_sub_heading'])):
                           $services_sub_heading = $selfintro_data['services_sub_heading'];
                        endif;
                        if(!empty($services_heading)):
					    ?>
						<div class="prt_heading_wrapper">
							<div class="prt_heading">
							    <h1><?php echo esc_html($services_heading); ?></h1>
								<?php if($typedsettings == 'on'): ?>
								    <div class="typed_strings_strength">
								       <p class="write_strength" data-strings-strength="<?php echo esc_html($services_sub_heading); ?>">
									   <?php echo esc_html($services_sub_heading); ?></p>
								    </div>
								<?php else: ?>
								    <p><?php echo esc_html($services_sub_heading); ?></p>
								<?php endif; ?>
							</div>
						</div>
						<?php endif; ?>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prt_services_slider_imgs">
						<?php 
						$services_about_images = $logoimages = '';
						$attachment_id = $selfintro_logoimages ='';
						$i = 1;
                        if(!empty($selfintro_data['services_about_images'])):
                        $services_about_images = $selfintro_data['services_about_images'];
                        endif;
                        if(!empty($services_about_images)):
                            foreach($services_about_images as $images_url):
                            if(!empty($images_url['about_images']['url'])):
                               $attachment_id = $images_url['about_images']['attachment_id'];
                                 $selfintro_logoimages = wp_get_attachment_url($attachment_id, 'full');
                                 $logoimages = selfintro_resize($selfintro_logoimages, 470, 390); 
                            endif;
                            if(!empty($logoimages)):
                             if($i == 1):
                                echo '<img class="img_'.esc_attr($i).' active" src="'.esc_url($logoimages).'" alt="'.esc_html__('Service','selfintro').'">';
                              else:
                                echo '<img class="img_'.esc_attr($i).'" src="'.esc_url($logoimages).'" alt="'.esc_html__('Service','selfintro').'">'; 
                             endif;
                            endif;
                            $i++;
    						endforeach;
						endif;
						?>	
						</div> 
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prt_services_slider_box">
						<?php 
						$our_services = '';
						$i = 1;
                        if(!empty($selfintro_data['our_services'])):
                          $our_services = $selfintro_data['our_services']; 
                        endif;
						if(!empty($our_services)):
                        foreach($our_services as $values):
                        $attachment_id=$selfintro_logoimages=$logoimages='';
                        if(!empty($values['services_icon']['url'])):
                                $attachment_id = $values['services_icon']['attachment_id'];
                                 $selfintro_logoimages = wp_get_attachment_url($attachment_id, 'full');
                                 $logoimages = selfintro_resize($selfintro_logoimages, 86, 100); 
                        endif;
                        if($i==1):
                          echo '<div class="prt_services_slider_text prt_img_click active" id="'.esc_attr($i).'">';
                        else:
                          echo '<div class="prt_services_slider_text prt_img_click " id="'.esc_attr($i).'">';
                        endif;
                        if(!empty($logoimages)):
                             echo '<span><img src="'.esc_url($logoimages).' " alt="'.esc_html__('Service icon','selfintro').'"></span>';
                        endif;
						if(!empty($values['title'])):
						 	echo '<h4>'.esc_html($values['title']).'</h4>';
						endif;
						if(!empty($values['descreption'])):
						      echo '<p>'.esc_html($values['descreption']).'</p>';
						endif;
						echo '</div>';
						$i++;
					   endforeach; 
					   endif;
					    $award_bg_image = '';
                        if(!empty($selfintro_data['award_bg_image']['url'])):
                           $award_bg_image = $selfintro_data['award_bg_image']['url'];
                        endif;
                        $bg_image_url = '';
                        if(!empty($award_bg_image)):
                           $bg_image_url = 'background-image:url(' .$award_bg_image. ');';
                        endif;
					   ?> 
						</div>
					</div>
				</div>
			</div> 
		</div>
		<div class="prt_couter_wrapper prt_toppadder80 prt_bottompadder50" style="<?php printf($bg_image_url); ?>" >
			<div class="container">
				<div class="row">
				<?php 
				$our_award = $logoimages = $selfintro_logoimages = $attachment_id= '';
                if(!empty($selfintro_data['our_award'])):
                   $our_award = $selfintro_data['our_award'];
                endif;
                if(!empty($our_award)):
                   foreach($our_award as $values):
                       if(!empty($values['award_icon']['url'])):
                        $attachment_id = $values['award_icon']['attachment_id'];
                        $selfintro_logoimages = wp_get_attachment_url($attachment_id, 'full');
                        $logoimages = selfintro_resize($selfintro_logoimages, 100, 100); 
                        endif;
                        $award_number = '';
                        if(!empty($values['award_number'])):
                          $award_number = $values['award_number'];
                        endif;
                        $award_title = '';
                        if(!empty($values['award_title'])):
                          $award_title = $values['award_title'];
                        endif;
    				echo '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
    						 <div class="prt_counter_box">';
    						  if(!empty($logoimages)):
    							 echo '<img src="'.esc_url($logoimages).'" alt="'.esc_html__('Clients','selfintro').'">';
    						  endif;
    						  if(!empty($award_number)):
    							 echo'<h3 class="timer" data-from="0" data-to="'.esc_html($award_number).'" data-speed="5000"></h3>';
    						 endif;	 
    						 if(!empty($award_title)):
    							 echo '<p>'.esc_html($award_title).'</p>';
    						 endif;
    				echo '</div>
    					</div>';
					endforeach;
					endif;
					?>
				</div>
			</div>
		</div>
		<div class="prt_skills_wrapper prt_toppadder115 prt_bottompadder115">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="prt_heading_wrapper">
						    <?php
						    $skills_heading = '';
                            if(!empty($selfintro_data['skills_heading'])):
                              $skills_heading = $selfintro_data['skills_heading'];
                            endif;
                            $skills_sub_heading = '';
                            if(!empty($selfintro_data['skills_sub_heading'])):
                               $skills_sub_heading = $selfintro_data['skills_sub_heading'];
                            endif;
                            if(!empty($skills_heading)):
						        echo '<div class="prt_heading">
    								    <h1>'.esc_html($skills_heading).'</h1>';
									if($typedsettings == 'on'): 
								    echo'<div class="typed_strings_skills">
									      <p class="write_skills" data-strings-skills="'.esc_html($skills_sub_heading).'">'.esc_html($skills_sub_heading).'</p>
								        </div>';
									else: 
										echo '<p>'.esc_html($skills_sub_heading).'</p>';
									endif;	
    							echo '</div>';
							endif;
							?>
						</div>
					</div>
			   <?php
				$our_skills = '';
				$idv = 1;
                if(!empty($selfintro_data['our_skills'])):
                    $our_skills = $selfintro_data['our_skills'];
                endif;
				if(!empty($our_skills)):
                    foreach($our_skills as $values):
                    $percent = '';
                    if(!empty($values['skills_number'])):
                       $percent  = $values['skills_number'];
                    endif;
                    $bgFill = '';
                    if(!empty($values['skills_color_bgFill'])):
                       $bgFill  = $values['skills_color_bgFill'];
                    endif;
                    $frFill = '';
                    if(!empty($values['skills_color_frFill'])):
                       $frFill  = $values['skills_color_frFill'];
                    endif;
                    $textcolor = '';
                    if(!empty($values['skills_textcolor'])):
                       $textcolor  = $values['skills_textcolor'];
                    endif;
                    $skill_bgimage = '';
                    if(!empty($values['skills_icon']['url'])):
                       $skill_bgimage  = $values['skills_icon']['url'];
                    endif;
            	   ?>
            	   <script>
                	jQuery(document).ready(function ($) {
                        "use strict";
                	   jQuery('#circle-<?php echo esc_js($idv); ?>').circleDiagram();
                	});
            		</script>
            		<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 text-center">
                    <div id="circle-<?php echo esc_html($idv); ?>"
            		     class="diagram" style="background-image:url(<?php echo esc_html($skill_bgimage); ?>); background-size:cover; background-repeat:no-repeat; background-position:center;"
            		     data-circle-diagram='{
            			"percent": "<?php echo esc_html($percent);?>%",
            			"size": "200",
            			"borderWidth": "8",
            			"bgFill": "<?php echo esc_html($bgFill); ?>",
            			"frFill": "<?php echo esc_html($frFill); ?>",
            			"textSize": "30",
            			"textColor": "<?php echo esc_html($textcolor); ?>"
            			}'>
            	      </div>
            	       <?php 
            	        if(!empty($values['skills_title'])):
						  echo '<h5>'.esc_html($values['skills_title']).'</h5>';
					    endif;
            	       ?>
            	    </div>
                    <?php 
                     $idv++;
					 endforeach;
					endif;
					?> 
				</div>
			</div>
		</div>
		<div class="prt_client_slider_wrapper">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					    <?php
					    $clients_heading = '';
                        if(!empty($selfintro_data['clients_heading'])):
                          $clients_heading = $selfintro_data['clients_heading'];
                        endif;
                        $clients_sub_heading = '';
                        if(!empty($selfintro_data['clients_sub_heading'])):
                           $clients_sub_heading = $selfintro_data['clients_sub_heading'];
                        endif;
                        if(!empty($clients_heading)):
					    ?>
						<div class="prt_heading_wrapper">
						  <div class="prt_heading">
							<h1><?php echo esc_html($clients_heading); ?></h1>
							<?php if($typedsettings == 'on'): ?>
							<div class="typed_strings_clients">
							   <p class="write_clients" data-strings-clients="<?php echo esc_html($clients_sub_heading); ?>">
							   <?php echo esc_html($clients_sub_heading); ?></p>
							</div>
							<?php else: ?>
							   <p><?php echo esc_html($clients_sub_heading); ?></p>
							<?php endif; ?>
						   </div>
						</div>
					   <?php endif; ?>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="prt_client_slider">
						    <div class="owl-carousel owl-theme">
						        <?php 
						        $our_clients = $logoimages = $selfintro_logoimages = $attachment_id ='';
                                if(!empty($selfintro_data['our_clients'])):
                                  $our_clients = $selfintro_data['our_clients'];
                                endif;
                                if(!empty($our_clients)):
                                foreach($our_clients as $values):
                                if(!empty($values['clients_icon']['url'])):
                                $attachment_id = $values['clients_icon']['attachment_id'];
                                 $selfintro_logoimages = wp_get_attachment_url($attachment_id, 'full');
                                 $logoimages = selfintro_resize($selfintro_logoimages, 170, 103); 
                                 endif;
								 $clients_url = '';
									if(!empty($values['clients_url'])):
									  $clients_url = $values['clients_url'];
									endif;
    						     if(!empty($logoimages)):
    								echo '<div class="item">
    								     <a href="'.esc_url($clients_url).'"><img src="'.esc_url($logoimages).'" alt="'.esc_html__('Client','selfintro').'"></a>
    							  	    </div>';
    							 endif;
							    endforeach;
							  endif;
							  ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php selfintro_footer_copyright(); ?>	
</div>   