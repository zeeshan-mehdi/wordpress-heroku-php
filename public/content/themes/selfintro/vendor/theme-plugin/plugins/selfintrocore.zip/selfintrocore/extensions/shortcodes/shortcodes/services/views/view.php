<?php if(!defined('FW')) {
	die( 'Forbidden' );
}
$services_about_images = $logoimages = '';
$attachment_id = $selfintro_logoimages ='';
$i = 1;
$services_heading = ''; 
if(!empty($atts['services_heading'])):
    $services_heading = $atts['services_heading'];
endif;
$services_sub_heading = '';
if(!empty($atts['services_sub_heading'])):
   $services_sub_heading = $atts['services_sub_heading'];
endif;
if(!empty($atts['services_about_images'])):
   $services_about_images = $atts['services_about_images'];
endif; 
if(function_exists( 'fw_get_db_settings_option' )):	
   $selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?> 
<div class="prt_services_slider_wrapper prt_bottompadder80">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<?php if(!empty($services_heading)): ?>
						<div class="prt_heading_wrapper">
							<div class="prt_heading">
								<h1><?php echo esc_html($services_heading); ?></h1>
								<?php 
								if($typedsettings == 'on'): 
									echo'<div class="typed_strings_services">
										 <p class="write_services" data-strings-services="'.esc_html($services_sub_heading).'">'.esc_html($services_sub_heading).'</p></div>';
								else:  
									echo '<p>'.esc_html($services_sub_heading).'</p>';
								endif;
								?>
							</div>
						</div>
					<?php endif; ?>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prt_services_slider_imgs">
						<?php 
						if(!empty($services_about_images)):
                            foreach($services_about_images as $images_url):
                            if(!empty($images_url['about_images']['url'])):
                               $attachment_id = $images_url['about_images']['attachment_id'];
                                 $selfintro_logoimages = wp_get_attachment_url($attachment_id, 'full');
                                 $logoimages = selfintro_resize($selfintro_logoimages, 470, 390 , true); 
                            endif;
                            if(!empty($logoimages)):
                             if($i == 1):
                                echo '<img class="img_'.esc_attr($i).' active" src="'.esc_url($logoimages).'" alt="'.esc_html__('Service','selfintro').'">';
                              else:
                                echo '<img class="img_'.esc_attr($i).'" src="'.esc_url($logoimages).'" alt="'.esc_html__('Service','selfintro').'">'; 
                             endif;
                            endif;
                            $i++;
    						endforeach;
						endif;
						?>	
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prt_services_slider_box">
						<?php 
						$our_services = '';
						$i = 1;
                        if(!empty($atts['our_services'])):
                          $our_services = $atts['our_services']; 
                        endif;
						if(!empty($our_services)):
                        foreach($our_services as $values):
                        $attachment_id=$selfintro_logoimages=$logoimages='';
                        if(!empty($values['services_icon']['url'])):
                                $attachment_id = $values['services_icon']['attachment_id'];
                                 $selfintro_logoimages = wp_get_attachment_url($attachment_id, 'full');
                                 $logoimages = selfintro_resize($selfintro_logoimages, 86, 100 , true); 
                        endif;
                        if($i==1):
                          echo '<div class="prt_services_slider_text prt_img_click active" id="'.esc_attr($i).'">';
                        else:
                          echo '<div class="prt_services_slider_text prt_img_click " id="'.esc_attr($i).'">';
                        endif;   
                        if(!empty($logoimages)):
                             echo '<span><img src="'.esc_url($logoimages).' " alt="'.esc_html__('Service icon','selfintro').'"></span>';
                        endif;
						if(!empty($values['title'])):
						 	echo '<h4>'.esc_html($values['title']).'</h4>';
						endif;
						if(!empty($values['descreption'])):
						      echo '<p>'.esc_html($values['descreption']).'</p>';
						endif;
						echo '</div>';
						$i++; 
					   endforeach; 
					   endif; 
					    $award_bg_image = '';
                        if(!empty($selfintro_data['award_bg_image']['url'])):
                           $award_bg_image = $selfintro_data['award_bg_image']['url'];
                        endif;
                        $bg_image_url = '';
                        if(!empty($award_bg_image)):
                           $bg_image_url = 'background-image:url(' .$award_bg_image. ');';
                        endif;
					   ?> 
					  </div>
				  </div>
			  </div>
		</div>
</div>  