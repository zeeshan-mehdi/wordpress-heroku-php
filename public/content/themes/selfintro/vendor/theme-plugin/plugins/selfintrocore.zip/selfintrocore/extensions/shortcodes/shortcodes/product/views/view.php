<?php if ( ! defined( 'FW' ) ) {
	  die( 'Forbidden' );
   }
$heading = '';
if(!empty($atts['heading'])):
    $heading = $atts['heading'];
endif;
$sub_heading = '';
if(!empty($atts['sub_heading'])):
    $sub_heading = $atts['sub_heading'];
endif;
$producted_show = '';
if(!empty($atts['producted_show'])):
   $producted_show = $atts['producted_show'];
endif;
if(function_exists( 'fw_get_db_settings_option' )):	
   $selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
?>
<!--<div class="row">-->
 <div class="self_woocommerce_wrapper prt_toppadder80">
  <?php if(!empty($heading) || !empty($sub_heading)): ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="prt_heading_wrapper">
					<div class="prt_heading">
					    <?php if(!empty($heading)): ?>
						   <h1><?php printf($heading); ?></h1>
						<?php 
						 endif;
						 if(!empty($sub_heading)):
                            if($typedsettings == 'on'): 
							    echo'<div class="typed_strings_product">
								  <p class="write_product" data-strings-product="'.esc_html($sub_heading).'">'.esc_html($sub_heading).'</p></div>';
						    else:  
						        echo '<p>'.esc_html($sub_heading).'</p>';
					        endif;
						endif; 
						?> 
					</div>
				</div>
            </div> 
            <?php endif; ?>
          <div class="self_woocommerce_product product_slider">
		  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="owl-carousel owl-theme">
			<?php 
			$args = '';
			$args = array(
				'post_type' =>'product',
				'posts_per_page' =>$producted_show,
				);
			 $tr_query = new WP_Query($args);  
			 if($tr_query->have_posts()) :
			 while($tr_query->have_posts()): $tr_query->the_post();
			  if(class_exists("Woocommerce")){
				?>
				<div class="item">
					<?php wc_get_template_part( 'content', 'product' ); ?>
				</div>
				<?php
			  }
			 endwhile;
			 wp_reset_postdata();
			endif;
		   ?>
		</div>
     </div>
	 </div>
  </div>
<!--</div>--> 