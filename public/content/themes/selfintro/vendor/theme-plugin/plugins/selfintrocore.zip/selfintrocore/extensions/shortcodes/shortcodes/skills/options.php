<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$options = array(
     'skills_heading'  => array( 
    			'label' => esc_html__('Skills Heading', 'selfintro'),
    			'type' => 'text',
    			'value' => '',
    			'desc' => esc_html__('', 'selfintro'),
			), 	 
	  'skills_sub_heading'  => array( 
    			'label' => esc_html__('Skills Sub Heading', 'selfintro'),
    			'type' => 'text',
    			'value' => '',
    			'desc' => esc_html__('', 'selfintro'),
			), 	 
     'our_skills' =>array( 
		      'type' => 'addable-popup',
		      'value' => array(
			   array(
				    'our_skills' => 'Our Skills',
			        ),
	     	     ),
		      'label' => esc_html__('Add Skills', 'selfintro'),
		      'template' => '{{- objectives_title }}',
		      'popup-title' => null,
		      'size' => 'small', // small, medium, large
		      'limit' => 0, // limit the number of popup`s that can be added
	      	  'add-button-text' => esc_html__('Add', 'selfintro'), 
		      'sortable' => true,
		      'popup-options' => array(
		      'skills_title' => array(
		          'label' => esc_html__('Title', 'selfintro'),
		           'type' => 'text', 
	               ),
	            'skills_number' => array(
		             'label' => esc_html__('Number', 'selfintro'),
		             'type' => 'text', 
	                 ),
	           'skills_color_bgFill' => array(
                    'label' => __('Color BgFill', 'selfintro'),
                    'desc' => __('Select the BgFill color', 'selfintro'),
                    'value' => '',
                    'type' => 'color-picker'
                ),
                'skills_color_frFill' => array(
                    'label' => __('Color FrFill', 'selfintro'),
                    'desc' => __('Select the FrFill color', 'selfintro'),
                    'value' => '',
                    'type' => 'color-picker'
                ),
                'skills_textcolor' => array(
                    'label' => __('Text Color', 'selfintro'),
                    'desc' => __('Select the Text color', 'selfintro'),
                    'value' => '',
                    'type' => 'color-picker'
                ),
	            'skills_icon'  => array( 
			       'label' => esc_html__('Services Icon', 'selfintro'),
			       'desc' => esc_html__('Upload Services Icon Here.', 'selfintro'),
			        'type' => 'upload', 
			       ),   
			      ), 
	            ),	
 );