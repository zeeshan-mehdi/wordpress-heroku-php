<?php
/*
Plugin Name: Selfintro Core Plugin
Plugin URI: 
Description: This plugin create custom post type and some meta option.
Version: 1.0.0
Author:  
Author URI: http://themeforest.net/
*/
Class Selfintro {
    function selfintro_menu(){
	    require_once 'sectionview/section-menu.php';
	} 
    function selfintro_about(){
       require_once 'sectionview/section-about.php';
    } 
    function selfintro_contact(){
        require_once 'sectionview/section-contact.php';
    } 
    
    function selfintro_portfolio(){
        require_once 'sectionview/section-portfolio.php';
     } 
    function selfintro_strength(){
        require_once 'sectionview/section-strength.php';
    }
	function selfintro_shop(){
        require_once 'sectionview/section-shop.php';
    }	
} 
/**
 *Selfintro custom post type
 */
require_once 'selfintro-customposttype.php';

/**
 *selfintro Shortcode Extensions
 */
function selfintro_shortcode_extensions($locations) {
	$locations[
		dirname(__FILE__) . '/extensions'
	] = plugin_dir_url( __FILE__ ) . 'extensions';

	return $locations;
}
add_filter('fw_extensions_locations','selfintro_shortcode_extensions'); 
/**
 *Self-intro Portfolio 
 */ 
add_action( 'wp_ajax_selfintro_load_portfolio', 'selfintro_load_portfolio');
add_action( 'wp_ajax_nopriv_selfintro_load_portfolio', 'selfintro_load_portfolio'); 
function selfintro_load_portfolio(){
?>
<div class="prt_portfolio_box popup-gallery prt_animate">
		<?php
		$number = 1;
		$column = '3';   
		$portfolio_show_number = $_POST['click_value'];
		$args = array('post_type' => 'portfolio', 
					  'posts_per_page'=>$portfolio_show_number); 
		$selfintro_query = new WP_Query($args); 
		if($selfintro_query->have_posts()):
		  while($selfintro_query->have_posts()):
				$selfintro_query->the_post();
		$selfintro_data = ''; 
		if(function_exists( 'fw_get_db_post_option' )):	
			 $selfintro_data = fw_get_db_post_option(get_the_ID());
		endif;    
		$youtub_video_url = '';
		if(!empty($selfintro_data['video_url'])):	
			 $youtub_video_url = $selfintro_data['video_url'];
		endif; 
		$image_sub_title = '';
		if(!empty($selfintro_data['image_sub_title'])):	
			  $image_sub_title = $selfintro_data['image_sub_title'];
		endif; 
		$video_title = '';
		if(!empty($selfintro_data['video_title'])):	
				 $video_title = $selfintro_data['video_title'];
		 endif; 
		$video_sub_title = '';
		if(!empty($selfintro_data['video_sub_title'])):	
			 $video_sub_title = $selfintro_data['video_sub_title'];
		endif; 
		$portfolio_style = ''; 
		if(!empty($selfintro_data['portfolio_style'])):	
			 $portfolio_style = $selfintro_data['portfolio_style'];
		endif;  
		switch($portfolio_style) {
			 case 'style1':
			  echo '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">';
			  if(has_post_thumbnail(get_the_ID())):
				$attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
				$image_resize_url = selfintro_resize($attachment_url,360,360,true);
				$video_image_url = '';
			  if(!empty($selfintro_data['video_image']['attachment_id'])):	
					$attachment_id = $selfintro_data['video_image']['attachment_id'];
					$video_image_corup = wp_get_attachment_url($attachment_id, 'full');
					$video_image_url = selfintro_resize($video_image_corup,360,360,true);
				endif; 
			 endif;  
			 break;
			case 'style2':
			echo '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">';
				$video_image_url = '';
			if(!empty($selfintro_data['video_image']['attachment_id'])):	
				 $attachment_id = $selfintro_data['video_image']['attachment_id'];
				 $video_image_corup = wp_get_attachment_url($attachment_id, 'full');
				 $video_image_url = selfintro_resize($video_image_corup,760,360,true);
			endif; 
			if(has_post_thumbnail(get_the_ID())):
				$attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
				$image_resize_url = selfintro_resize($attachment_url,760,360,true);
			 endif;  
			 break;
			 default:
			 echo '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">';
			 if(has_post_thumbnail(get_the_ID())):
				$attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
				$image_resize_url = selfintro_resize($attachment_url,360,360,true);
			 endif;  
			 $video_image_url = '';
			 if(!empty($selfintro_data['video_image']['attachment_id'])):	
				   $attachment_id = $selfintro_data['video_image']['attachment_id'];
				   $video_image_corup = wp_get_attachment_url($attachment_id, 'full');
				   $video_image_url = selfintro_resize($video_image_corup,360,360,true);
			  endif; 
		}
?> 
<a class="imageopen" href="<?php echo esc_url($attachment_url); ?>" title="<?php esc_html_e('Portfolio','selfintro') ?>">
	<div class="prt_portfolio_img">
	  <?php if(!empty($image_resize_url)): ?>
		<img src="<?php echo esc_url($image_resize_url); ?>" alt="<?php esc_html_e('Portfolio','selfintro') ?>">
		 <?php endif; ?>
	  <div class="prt_portfolio_text">
		 <h4><?php the_title(); ?></h4> 
	     <p><?php echo esc_html($image_sub_title)?></p>
	</div>
  </div>
</a>
<?php if(!empty($youtub_video_url)): ?>
<a class="popup-youtube" href="<?php echo esc_url($youtub_video_url); ?>" title="<?php echo esc_html($video_title); ?>">
<?php if(!empty($video_image_url)): ?>
	<div class="prt_portfolio_img">
	  <img src="<?php echo esc_url($video_image_url); ?>" alt="<?php esc_html_e('Portfolio','selfintro'); ?>">
	  <div class="prt_portfolio_text">
		<?php if(!empty($video_title)): ?>
			<h4><?php echo esc_html($video_title); ?></h4>
		<?php
	endif;
	 if(!empty($video_sub_title)): ?>
	    <p><?php echo esc_html($video_sub_title); ?></p>
	<?php endif; ?>
  </div>
</div>
<?php endif; ?>
</a> 
<?php endif; ?> 
</div>
<?php 
 $number++;
endwhile;	
endif; 
wp_reset_postdata();
$num = $args = '';
   $args = array( 'post_type'=>'portfolio','posts_per_page' => -1 );
   $num = count( get_posts( $args ) );
if($portfolio_show_number >= $num ) 
{ ?>
	<style scoped> 
	.ajxload{display:none;}
	</style>
<?php
}
wp_die();			  	
}
/**
 *selfintro product load
 */
add_action( 'wp_ajax_selfintro_product_load', 'selfintro_product_load');
add_action( 'wp_ajax_nopriv_selfintro_product_load', 'selfintro_product_load'); 
function selfintro_product_load(){
$producted_show = $_POST['click_value'];
$args = '';
$args = array(
        'post_type' =>'product',
        'posts_per_page' =>$producted_show,
        );
    $tr_query = new WP_Query($args); 
    if($tr_query->have_posts()) :
	    while($tr_query->have_posts()): $tr_query->the_post();
		  if(class_exists("Woocommerce")){
			 wc_get_template_part( 'content', 'product' );
		   }
	    endwhile;
        wp_reset_postdata();
	endif;
	$num = $args = '';
	$args = array( 'post_type'=>'product','posts_per_page' => -1 );
	$num = count( get_posts( $args ) );
	if($portfolio_show_number >= $num){ 
	?> 
	<style scoped> 
	   .ajxload{display:none;}
	</style>
    <?php  
  }
wp_die();
} 
/**
 * Demo Content Important
 */
function  selfintro_filter_fw_ext_backups_demos($demos){
	$demos_array = array(
	    'blackbox' => array(
			'title' => esc_html__('Box Block', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/03.jpg'),
			'preview_link' => 'http://kamleshyadav.in/wp/selfIntro/',
		),
		'blacksingle' => array(
			'title' => esc_html__('Single Black', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/02.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfIntro/singlepage/',
		),
		'header_two' => array(
			'title' => esc_html__('Header Style Two', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/06.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfIntro/section-selfintro/',
		), 
		'whitebox' => array(
			'title' => esc_html__('Box White', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/04.jpg'),
			'preview_link' => 'http://kamleshyadav.in/wp/selfIntro/selfintro-white/',
		),
		'whitesingle' => array(
			'title' => esc_html__('Single White', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/01.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfIntro/singlepage-white/',
		),
		'header_one' => array(
			'title' => esc_html__('Header Style One', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/05.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfIntro/selfintro-section-white/',
		),
		'darkheadervideo' => array(
			'title' => esc_html__('Dark Header Video', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/dark-header-video.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/dark-header-video/',
		),
		'lightheadervideo' => array(
			'title' => esc_html__('Light Header Video', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/light-header-video.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/light-header-video/',
		), 
		'boxedlightvideo' => array(
			'title' => esc_html__('Boxed Light Video', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/boxed-light-video.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/boxed-light-video/',
		),
		'boxeddarkvideo' => array(
			'title' => esc_html__('Boxed Dark Video', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/boxed-dark-video.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/boxed-dark-video/',
		),
		'darksinglevideo' => array(
			'title' => esc_html__('Dark Single Video', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/dark-single-video.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/dark-single-video/',
		),
		'lightsinglevideo' => array(
			'title' => esc_html__('Light Single Video', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/light-single-video.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/light-single-video/',
		),
		'darkheadertyped' => array(
			'title' => esc_html__('Dark Header Typed', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/dark-header-typed.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/dark-header-typed/',
		),
		'lightheadertyped' => array(
			'title' => esc_html__('Light Header Typed', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/light-header-video.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/light-header-typed/',
		),
		'boxedlighttyped' => array(
			'title' => esc_html__('Boxed Light Typed', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/boxed-light-typed.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/boxed-light-typed/',
		),
		'boxeddarktyped' => array(
			'title' => esc_html__('Boxed Dark Typed', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/boxed-dark-typed.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/boxed-dark-typed/',
		),
		'darksingletyped' => array(
			'title' => esc_html__('Dark Single Typed', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/dark-single-typed.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/dark-single-typed/',
		),
		'lightsingletyped' => array(
			'title' => esc_html__('Light Single Typed', 'selfintro'),
			'screenshot' => esc_url(get_template_directory_uri().'/assets/images/demo/light-single-typed.jpg'),
			'preview_link' => 'http://kamleshyadav.com/wp/selfintro-v1.2/light-single-typed/',
		), 
	);
    foreach ($demos_array as $id => $data) {
		$demo = new FW_Ext_Backups_Demo($id, 'piecemeal', array(
			'url' => 'http://motothemes.com/traininginstitute-v/selfintrodemo/',
			'file_id' => $id,
		));
		$demo->set_title($data['title']);
		$demo->set_screenshot($data['screenshot']);
		$demo->set_preview_link($data['preview_link']);
        $demos[$demo->get_id()] = $demo;
        unset($demo);
	}
   return $demos;  
}
$dir = get_template_directory().'/demo-content';
if(!is_dir($dir)):
add_filter('fw:ext:backups-demo:demos','selfintro_filter_fw_ext_backups_demos');  
endif;