<?php if ( ! defined( 'FW' ) ) {
	  die( 'Forbidden' );
   }
$heading = '';
if(!empty($atts['heading'])):
    $heading = $atts['heading'];
endif;
$sub_heading = '';
if(!empty($atts['sub_heading'])):
    $sub_heading = $atts['sub_heading'];
endif;
$show_blog = '';
if(isset($atts['show_blog'])):
   $show_blog = $atts['show_blog'];
endif;
if(function_exists( 'fw_get_db_settings_option' )):	
   $selfintro_data = fw_get_db_settings_option();  
endif; 
$typedsettings = '';
if(!empty($selfintro_data['banner_switch_typed'])):
	$typedsettings =$selfintro_data['banner_switch_typed'];
endif;
 ?>
<div class="prt_blog_wrapper prt_toppadder110">
    <div class="container">
        <div class="row">
           <?php if(!empty($heading) || !empty($sub_heading)): ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="prt_heading_wrapper">
					<div class="prt_heading">
					    <?php if(!empty($heading)): ?>
						   <h1><?php printf($heading); ?></h1>
						<?php 
						endif;
						if(!empty($sub_heading)): 
						    if($typedsettings == 'on'): 
							    echo'<div class="typed_strings_blog">
								    <p class="write_blog" data-strings-blog="'.esc_html($sub_heading).'">'.esc_html($sub_heading).'</p></div>';
						    else:  
						        echo '<p>'.esc_html($sub_heading).'</p>';
					        endif; 
						endif; ?>
					</div>
				</div> 
            </div> 
            <?php 
            endif;
            $selfintro_thumb_w =360;
			$selfintro_thumb_h =245;
            $args = array(
                   'post_type' =>'post',
				   'posts_per_page' =>$show_blog ,
                   'post_status' =>'publish',
                  );
            $self_query = new WP_Query($args);
            if($self_query->have_posts()):
                while($self_query->have_posts()): $self_query->the_post();
				if(has_post_thumbnail(get_the_ID())):
                   $self_attachment_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()), 'full');
			           $thum_image = selfintro_resize($self_attachment_url, $selfintro_thumb_w, $selfintro_thumb_h, true);
			    endif;	
			 ?>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="prt_blog_section">
                    <?php if(!empty($thum_image)): ?>
                    <div class="blog_img">
                       <img src="<?php echo esc_url($thum_image); ?>" alt="<?php echo get_the_title(); ?>" title="<?php echo get_the_title(); ?>" class="img-responsive">
                    </div>  
                    <?php endif; ?>
                    <div class="blog_text">
                       <h4><a href="<?php echo esc_url(get_the_permalink(get_the_ID(get_the_ID()))); ?>"><?php the_title(); ?></a></h4>
                        <p class="post_meta">
                          <?php selfintro_posted_on(); ?>
		                </p>  
                        <p><?php echo selfintro_the_excerpt(250); ?></p>
                        <a href="<?php echo esc_url(get_the_permalink(get_the_ID()));?>" class="prt_btn"><?php esc_html_e('read more','industry'); ?></a>
                    </div>    
                </div>
            </div>
            <?php
             endwhile;
             wp_reset_postdata();
            endif;
            ?>
        </div>    
    </div>    
</div>