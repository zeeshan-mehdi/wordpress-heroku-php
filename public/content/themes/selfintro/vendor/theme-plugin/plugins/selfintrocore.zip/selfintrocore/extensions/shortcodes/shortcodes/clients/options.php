<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} 
$options = array(
    'clients_heading'  => array( 
    			'label' => esc_html__('Clients Heading', 'selfintro'),
    			'type' => 'text',
    			'value' => '',
    			'desc' => esc_html__('', 'selfintro'),
			), 	 
	'clients_sub_heading'  => array( 
    			'label' => esc_html__('Clients Sub Heading', 'selfintro'),
    			'type' => 'text',
    			'value' => '',
    			'desc' => esc_html__('', 'selfintro'),
			), 
	'our_clients' =>array( 
		      'type' => 'addable-popup',
		      'value' => array(
			   array(
				    'our_clients' => 'Our Clients',
			        ),
	     	     ),
		      'label' => esc_html__('Add Clients', 'selfintro'),
		      'template' => '{{- objectives_title }}',
		      'popup-title' => null,
		      'size' => 'small', 
		      'limit' => 0, 
	      	  'add-button-text' => esc_html__('Add', 'selfintro'), 
		      'sortable' => true,
		      'popup-options' => array(
		        'clients_icon'  => array( 
			       'label' => esc_html__('Services Icon', 'selfintro'),
			       'desc' => esc_html__('Upload Services Icon Here.', 'selfintro'),
			        'type' => 'upload', 
			       ),  
			'clients_url'  => array( 
    			'label' => esc_html__('Clients Url', 'selfintro'),
    			'type' => 'text',
    			'value' => '',
    			'desc' => esc_html__('', 'selfintro'),
			), 	  
			       
			      ), 
	            ),	
);