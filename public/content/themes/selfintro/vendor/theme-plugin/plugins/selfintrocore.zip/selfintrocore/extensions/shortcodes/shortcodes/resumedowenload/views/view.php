<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} 
$button_text = '';
if(!empty($atts['button_text'])):
  $button_text = $atts['button_text'];
endif;
$resume_download = '';
if(!empty($atts['resume_download'])):
  $resume_download = $atts['resume_download'];
endif;
$resume_download_url = '';
if(!empty($atts['resume_download_url'])):
  $resume_download_url = $atts['resume_download_url'];
endif;
$button_style_change = '';
if(!empty($atts['button_style_change'])):
  $button_style_change = $atts['button_style_change'];
endif;
if(!empty($resume_download) || !empty($resume_download_url)):
 if($button_style_change =='left-side'):
   echo '<div class="self-resume-download left-style">';
 else:
   echo '<div class="self-resume-download right-style">'; 
 endif;
 if(!empty($resume_download)): ?>
  <a href="<?php echo esc_url($resume_download); ?>" class="prt_btn ">
  <?php else: ?>
  <a href="<?php echo esc_url($resume_download_url); ?>" class="prt_btn">
  <?php 
  endif;
  if(!empty($button_text)):
	echo esc_html($button_text); 
  else:
	esc_html_e('Download Resume','selfintro'); 
  endif; 
   ?>
   <i class="fa fa-download"></i>
  </a> 
</div>
<?php endif; ?>