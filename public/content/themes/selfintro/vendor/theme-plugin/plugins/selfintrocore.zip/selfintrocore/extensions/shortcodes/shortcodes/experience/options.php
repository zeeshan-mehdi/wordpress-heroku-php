<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} 
$options = array(
     'experience_heading'  => array( 
			'label' => esc_html__('Experience Heading', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			), 	 
	 'experience_sub_heading'  => array( 
			'label' => esc_html__('Experience Sub Heading', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			), 	  		
	 'experience_number'  => array( 
			'label' => esc_html__('Show Number Of Experience', 'selfintro'),
			'type' => 'text',
			'value' => '',
			'desc' => esc_html__('', 'selfintro'),
			), 
	);  	