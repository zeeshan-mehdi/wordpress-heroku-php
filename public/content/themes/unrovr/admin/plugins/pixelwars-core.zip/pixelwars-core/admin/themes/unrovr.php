<?php

	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/post-type-portfolio.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/meta-box-featured-media.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/meta-box-portfolio-details.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widgets.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/shortcodes.php');

?>