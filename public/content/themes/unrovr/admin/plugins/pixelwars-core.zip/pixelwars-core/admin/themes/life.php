<?php

	include_once($pixelwars_core_ABSPATH . 'admin/themes/life/meta-box-featured-media.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/life/widgets.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/life/share-links.php');

?>