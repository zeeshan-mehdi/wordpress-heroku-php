<?php

	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-social-media-icon.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-homepage-menu-item.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-contact-form.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-section-title.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-map.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-testimonial.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-fun-fact.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-client.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-process.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-progress-bar.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-service.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-timeline-title.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-timeline-event.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/unrovr/widget-button.php');

?>