<?php

	include_once($pixelwars_core_ABSPATH . 'admin/themes/life/widget-social-media-icon.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/life/widget-social-media-feed.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/life/widget-link-box.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/life/widget-about-me.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/life/widget-intro.php');
	include_once($pixelwars_core_ABSPATH . 'admin/themes/life/widget-main-slider.php');

?>